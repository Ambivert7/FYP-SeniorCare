const express = require('express');
const cors = require('cors'); // Add this line
const cron = require('node-cron');
const admin = require('firebase-admin');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');


// Initialize Firebase Admin SDK
const serviceAccount = require('./health-fit-86927-firebase-adminsdk-59iu4-df9c2e9b99.json');
const app = express();

app.use(cors());

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true })); // Parse URL-encoded bodies



admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    storageBucket: 'gs://health-fit-86927.appspot.com'
});

// Nodemailer configuration
const transporter = nodemailer.createTransport({
    service: 'Gmail',
    auth: {
        user: 'djhani36@gmail.com', // Your Gmail address
        pass: 'avdbehovxirmbncf' // Your Gmail password
    }
});
function generateOTP() {
    return Math.floor(100000 + Math.random() * 900000);
}
var globalOTP = generateOTP(); // Generate random OTP

function sendOTPByEmail(email) {
    const mailOptions = {
        from: 'no.repy@seniorcare.com', // Sender address
        to: email, // List of recipients
        subject: 'OTP for Doctor Registration', // Subject line
        text: `Your OTP for registration is: ${globalOTP}` // Plain text body
    };

    return transporter.sendMail(mailOptions);
}

// Firestore database instance
const db = admin.firestore();
const storage = admin.storage();
const storageRef = storage.bucket()

app.post("/regstu", async function (req, res) {
    var firstName = req.body.firstName;
    var lastName = req.body.lastName;
    var email = req.body.email;
    var specialty = req.body.specialty;
    var experience = req.body.experience;
    var otp = req.body.otp;
    var contactNumber = req.body.contactNumber;
    try {
        if (otp !== globalOTP.toString()) {
            console.log(otp + " " + globalOTP);
            throw new Error('Invalid OTP.');
        }
        globalOTP = generateOTP();
        // Add data to Firestore
        await db.collection('doctors').add({
            firstName: firstName,
            lastName: lastName,
            email: email,
            contactNumber: contactNumber,
            specialty: specialty,
            experience: experience,
        });

        res.status(200).json({ message: 'Registration successful!' });
    } catch (error) {
        console.error('Error registering doctor:', error);
        res.status(500).json({ error: error.message });
    }
});



// Endpoint to handle OTP generation and email sending
app.post('/generateOTP', async (req, res) => {
    try {
        const { email } = req.body;

        await sendOTPByEmail(email);

        res.status(200).json({ globalOTP });
    } catch (error) {
        console.error('Error generating OTP:', error);
        res.status(500).json({ error: 'An error occurred while generating OTP.' });
    }
});

// Function to fetch tokens for a specific user
async function getToken(userId) {
    const userTokensSnapshot = await db.collection('usersTokken').doc(userId).get();
    return userTokensSnapshot.exists ? userTokensSnapshot.data().tokken : null;
}

cron.schedule('* * * * *', async () => {
    try {
        const userIds = [];
        const userSnapshot = await db.collection('users').get();
        userSnapshot.forEach((doc) => {
            userIds.push(doc.id);
        });

        console.log('User IDs:', userIds);
        const currentTime = new Date();
        for (const userId of userIds) {
            const remindersRef = db.collection(`reminders_${userId}`);
            const remindersSnapshot = await remindersRef.get();

            for (const doc of remindersSnapshot.docs) {
                console.log('Reminder:', doc.data());
                const { medicationName, reminderTime, placeholder } = doc.data();
                if (placeholder) {
                    // Handle placeholder reminders
                    continue;
                }

                // Check if reminderTime is in a valid format
                const timeComponents = reminderTime.split(':');
                if (timeComponents.length !== 2) {
                    console.error('Invalid time format:', reminderTime);
                    continue;
                }

                const [hour, minute] = timeComponents;
                const scheduledTime = new Date();
                scheduledTime.setHours(parseInt(hour), parseInt(minute), 0, 0);

                console.log('Scheduled time:', scheduledTime);
                console.log('Current time:', currentTime);
                // Compare current time with scheduled time
                if (currentTime.getHours() === scheduledTime.getHours() &&
                    currentTime.getMinutes() === scheduledTime.getMinutes()) {
                    // Fetch tokens for the user
                    const token = await getToken(userId);
                    if (token) {
                        const notificationMessage = {
                            notification: {
                                title: 'Medicine Reminder',
                                body: 'Please Take your Medicine: ' + medicationName,
                            },
                            token: token,

                        };

                        await admin.messaging().send(notificationMessage);
                        console.log('Notification sent successfully to', token);
                    } else {
                        console.log('Token not found for user:', userId);
                    }
                }
                if (currentTime.getHours() === scheduledTime.getHours() &&
                    currentTime.getMinutes() === scheduledTime.getMinutes() + 5) {
                    // Fetch tokens for the user
                    const token = await getToken(userId);
                    if (token) {
                        const notificationMessage = {
                            notification: {
                                title: 'Medicine Reminder',
                                body: 'Please Take your Medicine Immediately: ' + medicationName,
                            },
                            token: token,
                        };

                        await admin.messaging().send(notificationMessage);
                        console.log('Notification sent successfully to', token);
                    } else {
                        console.log('Token not found for user:', userId);
                    }
                }
            }
        }
    } catch (error) {
        console.error('Error fetching and scheduling notifications:', error);
    }
});


// Start the Express server
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
    console.log(globalOTP);
});
