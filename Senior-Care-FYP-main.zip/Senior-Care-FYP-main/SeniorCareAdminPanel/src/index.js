import { initializeApp } from "firebase/app";
import { getFirestore, collection, addDoc, query, doc, getDocs, deleteDoc } from 'firebase/firestore';
import { getStorage, ref, uploadBytes,getDownloadURL } from 'firebase/storage';

const firebaseConfig = {
    apiKey: "AIzaSyBVNpTgrSRtec8-wwCX3UmaF35WAd9X-Rk",
    authDomain: "health-fit-86927.firebaseapp.com",
    projectId: "health-fit-86927",
    storageBucket: "health-fit-86927.appspot.com",
    messagingSenderId: "306759770710",
    appId: "1:306759770710:web:63879ec2d5be88d9bc91f7",
    measurementId: "G-1WBYVEN659"
};
const firebase = initializeApp(firebaseConfig);

const db = getFirestore();

document.addEventListener("DOMContentLoaded", function () {

    const addBookForm = document.getElementById('addBookForm') || null;
    if(addBookForm != null){
        addBookForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            console.log("In Function");

            const title = addBookForm.bookTitle.value;
            const pdfLink = addBookForm.pdfLink.value; // Retrieve PDF link
            const imgFile = addBookForm.imgAddress.files[0]; // Retrieve file object for image

            // Ensure PDF link is provided
            if (!pdfLink.trim()) {
                console.log('Please provide a PDF link.');
                return;
            }

            // Ensure image file is selected
            if (!imgFile) {
                console.log('Please select an image file.');
                return;
            }

            const supportedFormats = ['.jpg', '.jpeg', '.webp'];
            const isValidImgFormat = supportedFormats.some(format => imgFile.name.toLowerCase().endsWith(format));

            if (!isValidImgFormat) {
                console.log('Please select a valid image format (JPG, JPEG, WEBP).');
                return;
            }

            const storage = getStorage();
            const imgStorageRef = ref(storage, `images/${imgFile.name}`);

            try {
                // Upload image file
                await uploadBytes(imgStorageRef, imgFile);
                console.log('Image file uploaded successfully.');

                // Now, you can store the download URL of the uploaded image file in Firestore or perform any other actions.
                // For simplicity, let's just log the download URL.
                const imgDownloadURL = await getDownloadURL(imgStorageRef);
                console.log('Image Download URL:', imgDownloadURL);

                await addDoc(collection(db, 'books'), {
                    title: title,
                    pdfURL: pdfLink,
                    imageURL: imgDownloadURL
                });

                console.log('Book added to Firestore.');

            } catch (error) {
                console.error('Error uploading files to Firebase Storage: ', error);
            }
        });
    }
});



async function deleteBooks(firebaseId) {
    try {
        await deleteDoc(doc(db, 'books', firebaseId));
        console.log('Book deleted from Firestore');
    } catch (error) {
        console.error('Error deleting book from Firestore: ', error);
    }
    location.reload();
}

async function getAllBooks() {
    const booksCollection = collection(db, 'books');
    const querySnapshot = await getDocs(booksCollection);

    const books = [];
    querySnapshot.forEach(doc => {
        const bookData = doc.data();
        const book = {
            id: doc.id,
            name: bookData.name
        };
        books.push(book);
    });
    console.log(books);

    return books;
}
async function deleteFeed(firebaseId) {
    try {
        await deleteDoc(doc(db, 'feedback', firebaseId));
        console.log('feedback deleted from Firestore');
    } catch (error) {
        console.error('Error deleting book from Firestore: ', error);
    }
    location.reload();
}

async function getAllFeedback() {
    const feedCollection = collection(db, 'feedback');
    const querySnapshot = await getDocs(feedCollection);

    const feedback = [];
    querySnapshot.forEach(doc => {
        const feedData = doc.data();
        const feed = {
            id: doc.id,
            name: feedData.feedback
        };
        feedback.push(feed);
    });

    return feedback;
}
async function getAllUser() {
    const userCollection = collection(db, 'users');
    const querySnapshot = await getDocs(userCollection);

    const users = [];
    querySnapshot.forEach(doc => {
        const userData = doc.data();
        const user = {
            id: doc.id,
            name: userData.email
        };
        users.push(user);
    });

    return users;
}
//getAllBooks();

window.getAllBooks = getAllBooks;
window.deleteBooks = deleteBooks;
window.deleteFeed = deleteFeed;
window.getAllFeedback = getAllFeedback;


