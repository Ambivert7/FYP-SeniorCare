# Senior-Care-FYP

### Setting Up React Environment

To set up the React environment for this project, follow these steps:

1. **Environment Setup:** Refer to the [React Native documentation](https://reactnative.dev/docs/environment-setup) for instructions on setting up your environment.

2. **Installing Node Modules:**
   - After setting up the environment, navigate to the project directory in your terminal.
   - Run the following command in all three directories to install the necessary node modules:
     ```bash
     npm install
     ```

3. **Starting the Application:**
   - Once the node modules are installed, initiate the app by running the following command in your terminal:
     ```bash
     npx expo start
     ```
   - To launch the app on an Android device or emulator, press 'a' after Expo starts.

That's it! You're ready to start developing with Senior-Care-FYP. If you encounter any issues during setup or usage, please refer to our [documentation](https://github.com/yourusername/Senior-Care-FYP/wiki) or open an issue in the repository. Happy coding! 🚀
