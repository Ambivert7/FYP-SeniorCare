import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, ScrollView, TouchableOpacity } from 'react-native';
import {  collection, getDocs } from "firebase/firestore";
import styles from '../styles/careplane_style';

import { Firebase_Auth,Firebase_Db } from "../components/firebase_access";

const ViewCarePlanScreen = ({navigation}) => {
    const [loading, setLoading] = useState(true);
    const [carePlan, setCarePlan] = useState(null);
    const [caretaker, setCaretaker] = useState(null);
    const auth = Firebase_Auth;
    const user = auth.currentUser;
    const userID = user.uid;
    const db = Firebase_Db;
    useEffect(() => {
    
        const fetchCaretaker = async () => {
            const querySnapshot = await getDocs(collection(db, "connections"));
            querySnapshot.forEach((doc) => {
                if (doc.id === userID) {
                    const caretaker = doc.data().connectionDetails;
                    setCaretaker(caretaker);
                    console.log(caretaker);
                }
            });
        };
    
        fetchCaretaker();
    }, []); // Run only once on component mount
    

    useEffect(() => {
        const fetchCarePlan = async () => {
            try {
                const carePlansCollection = collection(db, `CarePlans`);
                const carePlansSnapshot = await getDocs(carePlansCollection);
                carePlansSnapshot.forEach((doc) => {
                    if (doc.id === caretaker) {
                        const carePlanData = doc.data();
                        setCarePlan(carePlanData);
                        setLoading(false);
                    }
                });
            } catch (error) {
                console.error('Error fetching care plan data:', error);
            } finally {
            }
        };

        fetchCarePlan();
    }, [caretaker]);

    const renderNutritionalCard = () => {
        return (
            <View style={[styles.card, { backgroundColor: '#90EE90' }]}>
                <Text style={styles.cardTitle}>Nutritional Needs</Text>
                <Text style={styles.cardKey}>Dietary Preferences:</Text>
                <Text>{carePlan?.nutritionalNeeds?.dietaryPreferences}</Text>
                <Text style={styles.cardKey}>Food Allergies:</Text>
                <Text>{carePlan?.nutritionalNeeds?.foodAllergies}</Text>
                <Text style={styles.cardKey}>Special Dietary Requirements:</Text>
                <Text>{carePlan?.nutritionalNeeds?.specialRequirements}</Text>
            </View>
        );
    };
    
    const renderExerciseCard = () => {
        return (
            <View style={[styles.card, { backgroundColor: '#FFB6C1' }]}>
                <Text style={styles.cardTitle}>Exercise</Text>
                <Text style={styles.cardKey}>Preferred Types of Exercise:</Text>
                <Text>{carePlan?.exercise?.preferredTypes}</Text>
                <Text style={styles.cardKey}>Preferred Exercise Times:</Text>
                <Text>{carePlan?.exercise?.preferredTimes}</Text>
                <Text style={styles.cardKey}>Length of Each Exercise Session:</Text>
                <Text>{carePlan?.exercise?.lengthPerSession}</Text>
            </View>
        );
    };
    
    const renderAdditionalNotesCard = () => {
        return (
            <View style={[styles.card, { backgroundColor: '#FFFFE0' }]}>
                <Text style={styles.cardTitle}>Additional Notes/Comments</Text>
                <Text>{carePlan?.additionalNotes}</Text>
            </View>
        );
    };

    if (loading) {
        return (
            <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color="blue" />
            </View>
        );
    }

    return (
        <ScrollView contentContainerStyle={styles.container}>
            <Text style={styles.title}>Care Plan</Text>
            {renderNutritionalCard()}
            {renderExerciseCard()}
            {renderAdditionalNotesCard()}

            {/* Back Button */}
            <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
                <Text style={styles.backButtonText}>Back</Text>
            </TouchableOpacity>
        </ScrollView>
    );
};



export default ViewCarePlanScreen;
