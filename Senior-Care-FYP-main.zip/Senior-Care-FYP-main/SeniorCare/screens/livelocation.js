import React,{ useState, useEffect } from 'react';
import { View, TouchableOpacity, Text, StyleSheet,ActivityIndicator } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import MapView, { Marker } from 'react-native-maps';

import {
  
  setDoc,
  doc,
  getDocs,
  collection,
} from "firebase/firestore";

import styles from '../styles/liveloc_style';
import { Firebase_Auth,Firebase_Db } from "../components/firebase_access";





const MapScreen = () => {
  const navigation = useNavigation();
  const auth = Firebase_Auth;
  const db = Firebase_Db;
  const user = auth.currentUser;
  const userID = user.uid;
  const [lat, setLat] = useState(0);
  const [lng, setLng] = useState(0);
  const [connectionDetails, setConnectionDetails] = useState();
  const [loading, setLoading] = useState(true);


  const getUserInfo = async () => {
    try {
      const querySnapshot = await getDocs(collection(db, "connections"));
      querySnapshot.forEach((doc) => {
        if (doc.id === userID) {
            const connectionDetails = doc.data().connectionDetails;
            setConnectionDetails(connectionDetails);
        }
      });
    } catch (error) {
      // Handle any errors that might occur during the process
      console.error("Error fetching appointments:", error);
    }
  };
  const getUserLatLng = async () => {
    try {
      const querySnapshot = await getDocs(collection(db, "location"));
      querySnapshot.forEach((doc) => {
        if (doc.id === connectionDetails) {
            const lats = doc.data().latitude;
            const lngs = doc.data().longitude;
            setLat(lats);
            setLng(lngs);
            console.log(lats+" "+lngs);
            setLoading(false);
        }
      });
    } catch (error) {
      // Handle any errors that might occur during the process
      console.error("Error fetching appointments:", error);
    }
  };
  useEffect(() => {
    getUserInfo();
  }, []);

  useEffect(() => {
    if (connectionDetails) {
      getUserLatLng();
    }
  }, [connectionDetails]);


  const handleBackPress = () => {
    navigation.goBack();
  };

  if (loading) {
    return  (
      <View >
        <ActivityIndicator size="large" color="#0000ff" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1 }}>
      <MapView
        style={{ flex: 1 }}
        initialRegion={{
          latitude: lat,
          longitude: lng,
          latitudeDelta: 0.0922,
          longitudeDelta: 0.0421,
        }}
      >
        <Marker coordinate={{ latitude: lat, longitude: lng }} />
      </MapView>
      <TouchableOpacity onPress={handleBackPress} style={styles.backButton}>
        <Text style={styles.backButtonText}>Back</Text>
      </TouchableOpacity>
    </View>
  );
};

export default MapScreen;