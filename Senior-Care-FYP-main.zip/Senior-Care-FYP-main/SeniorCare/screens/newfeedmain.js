import React, { useState, useEffect } from 'react';
import { SafeAreaView, FlatList, View, Text, StyleSheet, StatusBar, Image,TouchableOpacity } from 'react-native';
import axios from 'axios';
import { useNavigation } from '@react-navigation/native';
import styles from '../styles/pdf_style';

const NewsScreen = () => {
  const [articles, setArticles] = useState([]);
  const navigation = useNavigation();

  useEffect(() => {
    const fetchArticles = async () => {
      try {
        const response = await axios.get('https://newsapi.org/v2/top-headlines', {
          params: {
            sources: 'bbc-news',
            apiKey: 'b057199e5fcc44999cc24604e6cf3edc', // Use your API key here
          },
        });
        setArticles(response.data.articles);
      } catch (error) {
        console.error('Error fetching articles:', error);
      }
    };
    fetchArticles();
  }, []);

  const renderArticle = ({ item }) => (
    <View style={styles.newsarticleContainer}>
      {item.urlToImage && <Image source={{ uri: item.urlToImage }} style={styles.newsarticleImage} />}
      <Text style={styles.newsarticleTitle}>{item.title}</Text>
      <Text style={styles.newsarticleDescription}>{item.description}</Text>
    </View>
  );
  const handleBackPress = () => {
    navigation.goBack();
  };

  return (
    <SafeAreaView style={styles.newscontainer}>
      <FlatList
        data={articles}
        keyExtractor={(item) => item.title}
        renderItem={renderArticle}
      />
      <TouchableOpacity onPress={handleBackPress} style={styles.newsbackButton}>
        <Text style={styles.newsbackButtonText}>Back</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
};

NewsScreen.navigationOptions = ({ navigation }) => ({
    headerLeft: () => (
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <Ionicons name="arrow-back" size={24} color="black" />
      </TouchableOpacity>
    ),
  });


export default NewsScreen;
