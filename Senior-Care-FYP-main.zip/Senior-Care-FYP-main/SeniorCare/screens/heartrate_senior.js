import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, Platform, Dimensions } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/Ionicons';
import styles from '../styles/heart_style';
import Svg, { Circle, G, Text as SvgText, TSpan } from 'react-native-svg';
import {
    GestureHandlerRootView,
    PanGestureHandler, State
} from 'react-native-gesture-handler';

import { Firebase_Auth, Firebase_Db } from '../components/firebase_access';
import { collection, getDocs } from "firebase/firestore";

import HeartRateChart from '../components/heartratechart';

const HeartRateScreenCare = () => {
    const [heartRate, setHeartRate] = useState(0);
    const [heartRateArray, setHeartRateArray] = useState([]);
    const [bpDia, setBPDia] = useState(0);
    const [bpSys, setBPSys] = useState(0);
    const [steps, setSteps] = useState(0);
    const user = Firebase_Auth.currentUser;
    const userID = user.uid;
    const [seniorID, setSeniorID] = useState('');

    const fetchSenior = async () => {
        const querySnapshot = await getDocs(collection(Firebase_Db, "connections"));
        querySnapshot.forEach((doc) => {
            if (doc.id === userID) {
                const seniorID = doc.data().connectionDetails;
                setSeniorID(seniorID);
            }
        });
    }
    const navigation = useNavigation(); // Initialize navigation
    const handleGoBack = () => {
        navigation.goBack();
    };

    useEffect(() => {
        fetchSenior();
    }, []);
    useEffect(() => {
        readSampleData();
    }, [seniorID]);
    const readSampleData = async () => {
        const healthData = await getHealthDataFromFirebase(seniorID);
        console.log(healthData);
        setBPDia(healthData[0].bpDia);
        setBPSys(healthData[0].bpSys);
        setSteps(healthData[0].steps);
        setHeartRate(healthData[0].heartRate);
        setHeartRateArray(healthData[0].heartRateArray);
        const timestamp = healthData[0].Timestamp;
        const date = timestamp.toDate(); // Convert Firebase Timestamp to JavaScript Date object

        const formattedDate = `${date.toLocaleDateString()} ${date.toLocaleTimeString()}`;

        console.log(formattedDate);
    }
    useEffect(() => {
        if (Platform.OS !== 'android') {
            return;
        }
    });
    const getHealthDataFromFirebase = async (userID) => {
        try {
            const healthDataCol = collection(Firebase_Db, `healthData_${userID}`);
            const querySnapshot = await getDocs(healthDataCol);
            const healthData = querySnapshot.docs.map(doc => doc.data());
            // Sort the data based on the timestamp in descending order
            healthData.sort((a, b) => {
                if (a.Timestamp && b.Timestamp) {
                    return b.Timestamp.toMillis() - a.Timestamp.toMillis();
                } else if (a.Timestamp) {
                    return -1;
                } else if (b.Timestamp) {
                    return 1;
                } else {
                    return 0;
                }
            });
                return [healthData[0]];
        } catch (error) {
            console.error("Error getting health data: ", error);
            return [];
        }
    };
    

    const [value, setValue] = useState(100); // Initial value set to 70% of 200
    const onGestureEvent = (event) => {
        if (event.nativeEvent.state === State.END) {
            // Calculate the angle from the touch position
            const { x, y } = event.nativeEvent;
            const angle = Math.atan2(y - 130, x - 150) * (180 / Math.PI) + 180;

            // Calculate the value based on the angle
            let newValue = Math.round((angle / 360) * 200);
            if (newValue < 0) {
                newValue = 0;
            } else if (newValue > 200) {
                newValue = 200;
            }
            setValue(newValue);
        }
    };
    const renderItem = ({ item }) => (
        <View style={styles.bpItem}>
            <Text style={styles.bpmText}>{item.key}: {item.value}</Text>
        </View>
    );


    return (
        <View style={styles.container}>
            <TouchableOpacity style={styles.backButton} onPress={handleGoBack}>
                <Icon name="arrow-back" size={30} color="black" />
            </TouchableOpacity>

            <View style={styles.iconContainer}>
                <GestureHandlerRootView style={styles.container}>
                    <Svg height="300" width="300">
                        <Circle
                            cx="150"
                            cy="130"
                            r="100"
                            stroke="#ddd"
                            strokeWidth="20"
                            fill="transparent"
                        />
                        <Circle
                            cx="150"
                            cy="130"
                            r="100"
                            stroke="#FA8072"
                            strokeWidth="20"
                            strokeDasharray={`${(heartRate / 200) * 440} 628`}
                            fill="transparent"
                        />
                        <G x="150" y="130">
                            <SvgText
                                x="-25"
                                y="5"
                                fontSize="24"
                                fill="#000"
                                textAnchor="middle"
                            >
                                {heartRate} <TSpan dx="5">   /-bpm</TSpan>
                            </SvgText>
                        </G>
                    </Svg>
                    <PanGestureHandler onGestureEvent={onGestureEvent}>
                        <View style={styles.touchArea} />
                    </PanGestureHandler>
                </GestureHandlerRootView>
            </View>
            <HeartRateChart heartRateArray={heartRateArray} />
            <View>

            </View>
            {/* Display Blood Pressure */}
            <View style={styles.iconContainer}>
                <View style={styles.bpContainer}>
                    <Text style={styles.bpmText}>Blood Pressure:</Text>
                    <Text style={styles.bpmText}>Diastolic: {bpDia}</Text>
                    <Text style={styles.bpmText}>Systolic: {bpSys}</Text>
                    <Text style={styles.bpmText}>Steps Count: {steps}</Text>
                </View>
            </View>

        </View>
    );
};



export default HeartRateScreenCare;

