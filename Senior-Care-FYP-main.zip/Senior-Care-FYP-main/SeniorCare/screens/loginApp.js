import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Image, ActivityIndicator } from 'react-native';
import styles from '../styles/main_style';
import { onAuthStateChanged, signInWithEmailAndPassword, sendPasswordResetEmail,sendEmailVerification } from 'firebase/auth';
import { Firebase_Auth,Firebase_Db } from '../components/firebase_access';
import messaging from '@react-native-firebase/messaging';
import { useEffect } from 'react';
import { setDoc, doc } from 'firebase/firestore';



export default function LoginApp({navigation, route}) {
  const [loggedIn, setLoggedIn] = useState(false);
  const [tokken, setTokken] = useState('');
  const [loading, setLoading] = useState(false);

  onAuthStateChanged(Firebase_Auth, (user) => {
    if (user) {
      navigation.navigate("Home");
    } else {
      // user is not logged in
    }
  });
  async function requestUserPermission() {
    const authStatus = await messaging().requestPermission();
    const enabled =
      authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
      authStatus === messaging.AuthorizationStatus.PROVISIONAL;
  
    if (enabled) {
      console.log('Authorization status:', authStatus);
      getToken();
    }
  }
  const getToken = async () => {
    const token = await messaging().getToken();
    setTokken(token);
  }
  messaging().setBackgroundMessageHandler(async remoteMessage => {
    console.log('Message handled in the background!', remoteMessage);
  });
  useEffect(() => {
  },[]);


  const handleSignUp = () => {
    navigation.navigate("Signup");
  }
  
  const signIn = () =>{
    setLoading(true); // Set loading to true when starting sign in process
    signInWithEmailAndPassword(Firebase_Auth, username, password).then(async () => {
      console.log(Firebase_Auth.currentUser.emailVerified);
      if(Firebase_Auth.currentUser.emailVerified){
        await setDoc(doc(Firebase_Db, 'usersTokken', Firebase_Auth.currentUser.uid), {
          tokken: tokken,
        });
        navigation.navigate("Home");
      }else{
        alert('Please Use Verified Email');
        sendEmailVerification(Firebase_Auth.currentUser)
        .then(()=>{
          setTimeout(() => {
            alert('Verification email sent');
          }, 1000);
        })
        .catch(error => {
        console.log(error);
        alert(error);
        })
      }
      
    })
    .catch(error => {
      if(error.code === 'auth/invalid-credential'){
      alert('Invalid Credential');
      }
      else if(error.code === 'auth/invalid-email'){
        alert('Please input Correct!');
        }
      else {
        console.log(error.code);
      }
    })
    .finally(() => {
      setLoading(false); // Set loading to false after sign in process completes
    });
  }
  const resetUserPassword = async () => {
    if(validateEmail()){
    try {
      await sendPasswordResetEmail(Firebase_Auth, username);
      alert('Check your emails!');
    } catch (error) {
      if (error.code === 'auth/user-not-found') {
        alert('User not found');
      } else {
        console.log(error);
        alert('There was a problem with your request');
      }
    }
  }
  };
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({});

  const validateForm = () => {
    let formErrors = {};
    if (!username) formErrors.username = 'Username is required';
    if (!password) formErrors.password = 'Password is required';

    setErrors(formErrors);

    return Object.keys(formErrors).length === 0;
  };
  const validateEmail = () => {
    let formErrors = {};
    if (!username) formErrors.username = 'Username is required';

    setErrors(formErrors);

    return Object.keys(formErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validateForm()) {
      signIn();
      console.log('Submitted');
      setUsername('');
      setPassword('');
      setErrors({});
    }
  };

  return (
    <View style={styles.login_container}>
      <View style={styles.form}>
        <Image source={require('../assets/logo.png')} style={styles.image} />
        <Text style={styles.label}>Username</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter your username"
          onChangeText={(text) => setUsername(text)}
          value={username}
        />
        {errors.username ? <Text style={styles.errorText}>{errors.username}</Text> : null}
        <Text style={styles.label}>Password</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter your password"
          secureTextEntry
          onChangeText={(text) => setPassword(text)}
          value={password}
        />
        {errors.password ? <Text style={styles.errorText}>{errors.password}</Text> : null}

        <TouchableOpacity style={[styles.button, styles.greenButton]} onPress={handleSubmit} disabled={loading}>
          {loading ? (
            <ActivityIndicator color="#ffffff" />
          ) : (
            <Text style={styles.buttonText}>Login</Text>
          )}
        </TouchableOpacity>
        <View style={styles.signupButtonContainer}>
          <TouchableOpacity
            style={[styles.button, styles.redButton]}
            onPress={handleSignUp}
          >
            <Text style={styles.buttonText}>Signup</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.button, styles.blueButton]}
            onPress={resetUserPassword}
          >
            <Text style={styles.buttonText}>Reset Password</Text>
          </TouchableOpacity>
          </View>
      </View>
    </View>
  );
}