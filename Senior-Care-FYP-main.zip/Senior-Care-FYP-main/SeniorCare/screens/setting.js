import React, { useState, useEffect } from 'react';
import { View, TextInput, TouchableOpacity, Text, ActivityIndicator } from 'react-native';
import styles from "../styles/main_style";
import { setDoc, doc, getDoc } from "firebase/firestore";
import { sendEmail } from "../components/stmp_setup";
import { Firebase_Auth, Firebase_Db } from "../components/firebase_access";
import {
  getDocs,
  collection,
  query,
  where,
} from "firebase/firestore";

const SettingScreen = () => {
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState('');
  const [loading, setLoading] = useState(false);
  const [existingConnection, setExistingConnection] = useState(false);
  const [feedback, setFeedback] = useState('');

  const auth = Firebase_Auth;
  const db = Firebase_Db;
  const user = auth.currentUser;
  const userID = user.uid;

  useEffect(() => {
    const fetchConnection = async () => {
      try {
        const docSnap = await getDoc(doc(db, 'connections', userID));
        if (docSnap.exists()) {
          setExistingConnection(true);
        }
      } catch (error) {
        console.error('Error fetching connection:', error);
      }
    };

    fetchConnection();
  }, []);

  function generateOTP() {
    const digits = '0123456789';
    let OTP = '';
    for (let i = 0; i < 6; i++) {
      OTP += digits[Math.floor(Math.random() * 10)];
    }
    return OTP;
  }
  const getUserIDByEmail = async (email) => {
    try {
      const q = query(collection(db, 'users'), where('email', '==', email));
      const querySnapshot = await getDocs(q);
      if (querySnapshot.size > 0) {
          return querySnapshot.docs[0].id;
      } else {
          console.log('User not found');
          return null;
      }
      } catch (error) {
        setLoading(false);
      console.error('Error getting user:', error);
      return null;
      }
  };

  const sendOtpEmail = async () => {
    const generatedOTP = generateOTP();
    setOtpSent(generatedOTP);
    if (!email.trim()) {
      alert('Email is empty');
      return;
    }

    if (!/\S+@\S+\.\S+/.test(email)) {
      alert('Email is not in correct format');
      return;
    }
    setLoading(true); 

    try {
      await sendEmail(email, generatedOTP); 
      setLoading(false); 
      alert('OTP sent to ' + email);
    } catch (error) {
      console.error('Failed to send email:', error);
      setLoading(false); 
    }
  };

  const handleConnect = async () => {
    setLoading(true);
    if (!otp.trim()) {
      setLoading(false);
      alert('OTP is empty');
      return;
    }

    if (otp !== otpSent) {
      setLoading(false);
      alert('Invalid OTP');
      return;
    }

    const resolvedInputValue = await getUserIDByEmail(email);
    await setDoc(doc(db, 'connections', userID), { connectionDetails: resolvedInputValue });
    await setDoc(doc(db, 'connections', resolvedInputValue), { connectionDetails: userID });
    console.log('Connecting with:', email);

    setLoading(false); 
    setEmail('');
    setOtp('');
  };

  const submitFeedback = async () => {
    if (!feedback.trim()) {
      alert('Feedback is empty');
      return;
    }
  
    try {
      // Save feedback to Firebase
      await setDoc(doc(db, 'feedback', userID), { feedback: feedback });
      console.log('Feedback submitted:', feedback);
      setFeedback('');
      alert('Feedback submitted');
    } catch (error) {
      console.error('Failed to submit feedback:', error);
      alert('Failed to submit feedback');
    }
  };
  
  return (
    <View style={styles.home_container}>
      <Text style={styles.home_title}>Connect with Caretaker</Text>
      <TextInput
        style={styles.set_input}
        onChangeText={setEmail}
        value={email}
        placeholder="Enter your Caretaker Email"
        placeholderTextColor="#888"
        keyboardType="email-address"
        disabled={existingConnection}
      />
      <TouchableOpacity style={styles.set_button} onPress={sendOtpEmail} disabled={existingConnection}>
        <Text style={styles.set_buttonText}>Send OTP</Text>
      </TouchableOpacity>
      <TextInput
        style={styles.set_input}
        onChangeText={setOtp}
        value={otp}
        placeholder="Enter OTP"
        placeholderTextColor="#888"
        keyboardType="numeric"
        disabled={existingConnection}
      />
      <TouchableOpacity style={styles.set_button} onPress={handleConnect} disabled={existingConnection}>
        {loading ? (
          <ActivityIndicator size="small" color="#ffffff" />
        ) : (
          <Text style={styles.set_buttonText}>Connect</Text>
        )}
      </TouchableOpacity>
      <Text style={styles.home_title}>Feedback</Text>
      <TextInput
        style={[styles.set_input, { height: 150 }]}
        onChangeText={setFeedback}
        value={feedback}
        placeholder="Enter your feedback here"
        placeholderTextColor="#888"
        multiline={true}
        numberOfLines={4}
      />
      <TouchableOpacity style={styles.set_button} onPress={submitFeedback}>
        <Text style={styles.set_buttonText}>Submit Feedback</Text>
      </TouchableOpacity>
    </View>
  );
};

export default SettingScreen;
