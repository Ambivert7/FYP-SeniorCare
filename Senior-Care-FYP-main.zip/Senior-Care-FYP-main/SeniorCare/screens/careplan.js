import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, ActivityIndicator } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { useNavigation } from '@react-navigation/native';
import {  setDoc, doc, collection, getDocs } from "firebase/firestore";


import styles from '../styles/careplane_style';
import { Firebase_Auth,Firebase_Db } from "../components/firebase_access";



const CarePlanScreen = () => {
    const navigation = useNavigation();
    var auth = Firebase_Auth;
    const user = auth.currentUser;
    const userID = user.uid;
    const [loading, setLoading] = useState(false); 
    const [carePlan, setCarePlan] = useState([]);
    const [nutritionalNeeds, setNutritionalNeeds] = useState({
        dietaryPreferences: '',
        foodAllergies: '',
        specialRequirements: ''
    });

    const [exercise, setExercise] = useState({
        preferredTypes: '',
        preferredTimes: '',
        lengthPerSession: ''
    });
    const saveFormDataToFirebase = async () => {
        if (isFormComplete()) {
          try {
            setLoading(true);
            const newCarePlan = {
              nutritionalNeeds,
              exercise,
              additionalNotes,
            };
      
            const db = Firebase_Db;
            const carePlansCollection = collection(db, `CarePlans`);
            await setDoc(doc(carePlansCollection, userID), newCarePlan);
      
            const updatedCarePlan = await getDocs(carePlansCollection);
            const updatedCarePlanData = updatedCarePlan.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      
            setCarePlan(updatedCarePlanData);
      
            setNutritionalNeeds({ dietaryPreferences: '', foodAllergies: '', specialRequirements: '' });
            setExercise({ preferredTypes: '', preferredTimes: '', lengthPerSession: '' });
            setAdditionalNotes('');
            setLoading(false);
            alert('Care Plan saved successfully!');
          } catch (error) {
            console.error('Error saving care plan data:', error);
          }
        } else {
          console.warn('Form is not complete. Cannot save.');
        }
      };
      

    const [additionalNotes, setAdditionalNotes] = useState('');
    const isFormComplete = () => {
        if (
            nutritionalNeeds.dietaryPreferences === '' ||
            nutritionalNeeds.foodAllergies === '' ||
            nutritionalNeeds.specialRequirements === '' ||
            exercise.preferredTypes === '' ||
            exercise.preferredTimes === '' ||
            exercise.lengthPerSession === ''
        ) {
            return false;
        }
        return true;
    };

    return (
        <ScrollView contentContainerStyle={styles.container}>
            {loading && <ActivityIndicator size="large" color="blue" />}
            <Text style={styles.title}>Care Plan</Text>

            <Text style={styles.heading}>Nutritional Needs</Text>
            <Picker
                style={styles.input}
                selectedValue={nutritionalNeeds.dietaryPreferences}
                onValueChange={(itemValue) => setNutritionalNeeds({ ...nutritionalNeeds, dietaryPreferences: itemValue })}
            >
                <Picker.Item label="Select Dietary Preferences" value="" />
                <Picker.Item label="Vegetarian" value="Vegetarian" />
                <Picker.Item label="Vegan" value="Vegan" />
                <Picker.Item label="Keto" value="Keto" />
                <Picker.Item label="Other" value="Other" />
            </Picker>
            <TextInput
                style={styles.input}
                placeholder="Food Allergies or Restrictions"
                value={nutritionalNeeds.foodAllergies}
                onChangeText={(text) => setNutritionalNeeds({ ...nutritionalNeeds, foodAllergies: text })}
            />
            <TextInput
                style={styles.input}
                placeholder="Special Dietary Requirements"
                value={nutritionalNeeds.specialRequirements}
                onChangeText={(text) => setNutritionalNeeds({ ...nutritionalNeeds, specialRequirements: text })}
            />

            <Text style={styles.heading}>Exercise</Text>
            <Picker
                style={styles.input}
                selectedValue={exercise.preferredTypes}
                onValueChange={(itemValue) => setExercise({ ...exercise, preferredTypes: itemValue })}
            >
                <Picker.Item label="Select Preferred Types of Exercise" value="" />
                <Picker.Item label="Walking" value="Walking" />
                <Picker.Item label="Yoga" value="Yoga" />
                <Picker.Item label="Chair Exercises" value="Chair Exercises" />
                <Picker.Item label="Swimming" value="Swimming" />
                <Picker.Item label="Cycling" value="Cycling" />
                <Picker.Item label="Dancing" value="Dancing" />
            </Picker>
            <Picker
                style={styles.input}
                selectedValue={exercise.preferredTimes}
                onValueChange={(itemValue) => setExercise({ ...exercise, preferredTimes: itemValue })}
            >
                <Picker.Item label="Select Preferred Exercise Times" value="" />
                <Picker.Item label="Morning" value="Morning" />
                <Picker.Item label="Afternoon" value="Afternoon" />
                <Picker.Item label="Evening" value="Evening" />
            </Picker>
            <Picker
                style={styles.input}
                selectedValue={exercise.lengthPerSession}
                onValueChange={(itemValue) => setExercise({ ...exercise, lengthPerSession: itemValue })}
            >
                <Picker.Item label="Select Length of Each Exercise Session" value="" />
                <Picker.Item label="10 minutes" value="10" />
                <Picker.Item label="20 minutes" value="20" />
                <Picker.Item label="30 minutes" value="30" />
                <Picker.Item label="40 minutes" value="40" />
            </Picker>

            <Text style={styles.heading}>Additional Notes/Comments</Text>
            <TextInput
                style={[styles.input, styles.additionalNotes]}
                placeholder="Any additional information..."
                multiline
                value={additionalNotes}
                onChangeText={(text) => setAdditionalNotes(text)}
            />

            {/* Save Button */}
            <TouchableOpacity
                style={[styles.button, !isFormComplete() && styles.disabledButton]}
                onPress={() => {
                    if (isFormComplete()) {
                        saveFormDataToFirebase();
                    }
                }}
                disabled={!isFormComplete()}
            >
                <Text style={styles.buttonText}>Save</Text>
            </TouchableOpacity>

            {/* Back Button */}
            <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
                <Text style={styles.backButtonText}>Back</Text>
            </TouchableOpacity>

        </ScrollView>
    );
};


export default CarePlanScreen;
