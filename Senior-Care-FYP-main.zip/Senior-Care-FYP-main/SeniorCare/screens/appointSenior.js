import React, { useState, useEffect } from "react";
import {
    View,
    Text,
    ScrollView,
    ActivityIndicator,
    TouchableOpacity
} from "react-native";
import {  collection, getDocs } from "firebase/firestore";

import styles from "../styles/med_appoint_style";
import { Firebase_Auth,Firebase_Db } from "../components/firebase_access";


const AppointScreenSenior = ({ navigation }) => {
    const auth = Firebase_Auth;
    const user = auth.currentUser;
    const userID = user.uid;
    const [isLoading, setIsLoading] = useState(true);
    const db = Firebase_Db;
    const [modalVisible, setModalVisible] = useState(false);
    const [appointments, setAppointments] = useState([]);
    const [caretaker, setCaretaker] = useState('');

    const handleBackButton = () => {
        navigation.navigate("Home");
    };
    const getAppointmentFromDB = async (caretaker) => {
        setIsLoading(true);
        const appointsCollection = collection(db, `appoints_${caretaker}`);
        const appointsSnapshot = await getDocs(appointsCollection);
        const appointsData = appointsSnapshot.docs
          .map(doc => ({
            id: doc.id,
            ...doc.data(),
          }))
          .filter(appoints => appoints.date && appoints.description && appoints.time && appoints.title)
          .map(appoint => ({
            ...appoint,
            date: appoint.date.toDate(), // Convert Firebase Timestamp to Date
          }));
        setAppointments(appointsData);
        setIsLoading(false);
      };
    

    const fetchCaretaker = async () => {
        try {
            const querySnapshot = await getDocs(collection(db, "connections"));
            querySnapshot.forEach((doc) => {
                if (doc.id === userID) {
                    const caretakerID = doc.data().connectionDetails;
                    setCaretaker(caretakerID);
                    console.log(caretakerID);
                    getAppointmentFromDB(caretakerID);
                }
            });
        } catch (error) {
            console.error("Error fetching caretaker:", error);
        }
    };

    useEffect(() => {
        fetchCaretaker();
    }, []);

    return (
        <View style={styles.container}>
                <Text style={styles.title}>Appointments</Text>
            <TouchableOpacity onPress={handleBackButton} style={styles.backButton}>
                <Text style={styles.backButtonText}>Back</Text>
            </TouchableOpacity>
            <ScrollView>
                {isLoading ? (
                    <View style={styles.loadingContainer}>
                        <ActivityIndicator size="large" color="#0000ff" />
                    </View>
                ) : (
                    <View>
                        {appointments.length === 0 ? (
                            <Text style={styles.noAppointmentsText}>No appointments</Text>
                        ) : (
                            <View>
                                {appointments.map((appointment, index) => (
                                    <View key={index} style={styles.card}>
                                        <Text style={styles.cardTitle}>{appointment.title}</Text>
                                        <Text style={styles.cardTime}>Time: {appointment.time}</Text>
                                        <Text style={styles.cardDate}>
                                            Date: {new Date(appointment.date).toISOString().split('T')[0]}
                                        </Text>
                                        <Text style={styles.modalText}>
                                            Description: {appointment.description}
                                        </Text>
                                    </View>
                                ))}
                            </View>
                        )}
                    </View>
                )}
            </ScrollView>
        </View>
    );
};

export default AppointScreenSenior;
