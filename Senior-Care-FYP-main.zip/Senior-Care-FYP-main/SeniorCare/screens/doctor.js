import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Firebase_Db } from '../components/firebase_access';
import { collection, getDocs } from 'firebase/firestore';
import { useNavigation } from '@react-navigation/native';


const DoctorListScreen = () => {
    const [doctors, setDoctors] = useState([]);
    const navigation = useNavigation();
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function fetchDoctors() {
            const db = Firebase_Db;
            const doctorCollection = collection(db, 'doctors');
            const doctorSnapshot = await getDocs(doctorCollection);
            const doctorData = doctorSnapshot.docs.map((doc) => ({
                id: doc.id,
                ...doc.data(),
            }));
            setDoctors(doctorData);
            setLoading(false);
        }

        fetchDoctors();
    }, []);

    const renderDoctorItem = ({ item }) => (
        <TouchableOpacity style={styles.card}>
            <Text style={styles.title}>Name:</Text>
            <Text>{`${item.firstName} ${item.lastName}`}</Text>
            <Text style={styles.title}>Specialty:</Text>
            <Text>{item.specialty}</Text>
            <Text style={styles.title}>Email:</Text>
            <Text>{item.email}</Text>
            <Text style={styles.title}>Contact Number:</Text>
            <Text>{item.contactNumber}</Text>
            <Text style={styles.title}>Experience:</Text>
            <Text>{item.experience}</Text>
        </TouchableOpacity>
    );

    if (loading) {
        return (
            <View >
                <ActivityIndicator size="large" color="#0000ff" />
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
                <Text style={styles.backButtonText}>{'< Back'}</Text>
            </TouchableOpacity>
            <Text style={styles.mainTitle}>Registered Doctors</Text>
            <FlatList
                data={doctors}
                keyExtractor={item => item.id}
                renderItem={renderDoctorItem}
                contentContainerStyle={styles.list}
            />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: '#f0f0f0',
    },
    mainTitle: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
    },
    list: {
        paddingBottom: 20,
    },
    card: {
        backgroundColor: '#fff',
        padding: 10,
        marginBottom: 10,
        borderRadius: 5,
        elevation: 2,
    },
    cardTitle: {
        fontWeight: 'bold',
        marginBottom: 5,
    },
    backButton: {
        marginBottom: 20,
    },
    backButtonText: {
        color: 'blue',
        fontSize: 16,
    },
    title: {
        fontWeight: 'bold',
        fontSize: 16,
        marginBottom: 5,
    },
});

export default DoctorListScreen;

