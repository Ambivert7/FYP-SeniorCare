import React, { useState, useEffect } from "react";
import { View, Text, TouchableOpacity } from "react-native";
import styles from "../styles/main_style";
import {
  deleteDoc,
  doc,
  getDocs,
  collection,
} from "firebase/firestore";
import { Firebase_Auth,Firebase_Db } from "../components/firebase_access";
import { signOut } from "firebase/auth";
import * as Location from 'expo-location';
import getUserRole from '../components/user_role';


const ProfileScreen = ({ navigation }) => {
  const auth = Firebase_Auth;
  const db = Firebase_Db;
  const userID = auth.currentUser.uid;
  const [role, setRole] = useState("");

  const getUserRoleX = async () => { 
    const userRole = await getUserRole(userID);
    setRole(userRole);
  };
  const [userData, setUserData] = useState({
    name: "",
    age: "",
    phone: "",
    address: "",
  });
  const [shortName, setShortName] = useState(" ");
  useEffect(() => {
    getUserInfo();
    getUserRoleX();
  }, []);

  const stopBackgroundTask = async () => {
    try {
      await Location.stopLocationUpdatesAsync('sendLocationToFirebase');
      console.log('Background location updates stopped successfully');
    } catch (error) {
      console.warn('Failed to stop background location updates:', error);
    }
  };

  const getUserInfo = async () => {
    try {
      const querySnapshot = await getDocs(collection(db, "UserInfo"));
      querySnapshot.forEach((doc) => {
        if (doc.id === userID) {
          const { name, age, phone, address } = doc.data();
          setUserData({ name, age, phone, address });
          setShortName(name.charAt(0));
          console.log({ name, age, phone, address });
        }
      });
    } catch (error) {
      // Handle any errors that might occur during the process
      console.error("Error fetching appointments:", error);
    }
  };
  const handleEditProfile = () => {
    // Navigation logic to edit profile screen
    navigation.navigate("EditProfile");
  };
  const handleLogout = async () => {
    try {
      await deleteDoc(doc(Firebase_Db, 'usersTokken', Firebase_Auth.currentUser.uid));
      
      await signOut(Firebase_Auth);
      if(role === "Senior"){
        stopBackgroundTask();
      }
      navigation.navigate("Login");
    } catch (error) {
      console.error('Error signing out: ', error);
    }
  };

  return (
    <View style={styles.profile_container}>
      <View style={styles.profileImageContainer}>
        <Text style={styles.profileImageText}>{shortName}</Text>
      </View>

      <View style={styles.profileInfo}>
        <View style={styles.infoItem}>
          <Text style={styles.profile_label}>Name:</Text>
          <Text style={styles.info}>{userData.name}</Text>
        </View>
        <View style={styles.infoItem}>
          <Text style={styles.profile_label}>Age:</Text>
          <Text style={styles.info}>{userData.age}</Text>
        </View>
        <View style={styles.infoItem}>
          <Text style={styles.profile_label}>Phone:</Text>
          <Text style={styles.info}>{userData.phone}</Text>
        </View>
        <View style={styles.infoItem}>
          <Text style={styles.profile_label}>Address:</Text>
          <Text style={styles.info}>{userData.address}</Text>
        </View>

        {/* Add more user details as needed */}
      </View>
      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
        <Text style={styles.logoutButtonText}>Logout</Text>
      </TouchableOpacity>
    </View>
  );
};


export default ProfileScreen;
