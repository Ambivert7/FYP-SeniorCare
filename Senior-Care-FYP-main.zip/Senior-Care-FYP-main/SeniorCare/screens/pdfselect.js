import React, { useEffect, useState } from 'react';
import { FlatList, Text, TouchableOpacity, View, Image, ActivityIndicator } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import styles from '../styles/pdf_style';
import {  collection, getDocs } from 'firebase/firestore';
import { Firebase_Auth,Firebase_Db } from "../components/firebase_access";


export default function PDFListScreen() {
    const navigation = useNavigation();
    const [pdfs, setPdfs] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function fetchPdfs() {
            const db = Firebase_Db;
            const pdfsCollection = collection(db, 'books');
            const pdfsSnapshot = await getDocs(pdfsCollection);
            const pdfsData = pdfsSnapshot.docs.map((doc) => ({
                id: doc.id,
                ...doc.data(),
            }));
            setPdfs(pdfsData);
            setLoading(false);
        }

        fetchPdfs();
    }, []);

    const handlePress = (uri) => {
        navigation.navigate('PDFViewer', { uri });
    };

    if (loading) {
        return (
            <View >
                <ActivityIndicator size="large" color="#0000ff" />
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
                <Text style={styles.backButtonText}>{'< Back'}</Text>
            </TouchableOpacity>
            <FlatList
                data={pdfs}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => (
                    <TouchableOpacity onPress={() => handlePress(item.pdfURL)} style={styles.item}>
                        <Image source={{ uri: item.imageURL }} style={styles.thumbnail} />
                        <Text style={styles.title}>{item.title}</Text>
                    </TouchableOpacity>
                )}
            />
        </View>
    );
}
