import { useNavigation } from "@react-navigation/native";
import React, { useState, useEffect } from "react";
import {
  View,
  ImageBackground,
  ActivityIndicator,
} from "react-native";
import styles from "../styles/main_style";
import { Firebase_Auth,Firebase_Db } from "../components/firebase_access";

import getUserRole from "../components/user_role";

import { generateButtons, ButtonCard } from "../components/home_buttons";

import * as Location from 'expo-location';

import { setDoc,doc,getDocs,collection } from "firebase/firestore";

import { sendNotification } from "../components/alert_notification";

import { sendToFirebase } from '../components/sentofirebase';

const Home = () => {
  const navigation = useNavigation();
  const userID = Firebase_Auth.currentUser.uid;
  const [userRole, setUserRole] = useState("");
  const [loading, setLoading] = useState(true);
  const [latitude, setLatitude] = useState();
  const [longitude, setLongitude] = useState();
  const [caretaker, setCaretaker] = useState('');
  const [tokken, setTokken] = useState('');

  const fetchCaretaker = async () => {
    const querySnapshot = await getDocs(collection(Firebase_Db, "connections"));
    querySnapshot.forEach((doc) => {
      if (doc.id === userID) {
        const caretaker = doc.data().connectionDetails;
        setCaretaker(caretaker);
      }
    });
  }

  const fetchTokken = async () => {
    const querySnapshot = await getDocs(collection(Firebase_Db, "usersTokken"));
    querySnapshot.forEach((doc) => {
      if (doc.id === caretaker) {
        const tokken = doc.data().tokken;
        setTokken(tokken);
      }
    });
  }
  
  useEffect(() => {
      checkUserRole();
  }, [userRole]);

  const checkUserRole = async () => {
    try {
      let role = await getUserRole(userID);
      setUserRole(role);
      setLoading(false);
      try {
        if(role === "null"){
          alert("Unable to get user role!!");
          navigation.navigate("Login");
        }
        else if (role === "Senior") {
          console.log("User role is Senior");
          getPermission();
          startBackgroundTask();
        }
        else if(role === "Caretaker"){
          console.log("User role is Caretaker");
        }
      } catch (error) {
        console.error("Error fetching user role:", error);
      }
    } catch (error) {
      setLoading(false);
      console.error("Error fetching user role:", error);
    }
  };
  
  const getPermission = async () => {
    let foregroundPermission = await Location.requestForegroundPermissionsAsync();
    let backgroundPermission = await Location.requestBackgroundPermissionsAsync();

    if (foregroundPermission.status !== "granted" || backgroundPermission.status !== "granted") {
      alert("Permission to access location was denied");
      return;
    }
  };

  const startBackgroundTask = async () => {
    try {
      await Location.startLocationUpdatesAsync('sendLocationToFirebase', {
        accuracy: Location.Accuracy.High,
        timeInterval: 120000, // 2 minutes in milliseconds
        distanceInterval: 0,
        showsBackgroundLocationIndicator: true,
      });
      console.log('Background location updates started successfully');
    } catch (error) {
      console.error('Failed to start background location updates:', error);
    }
  };

  const handleButtonPress = (buttonName) => {
      navigation.navigate(buttonName);
  };
  const handleEmgAlert = (buttonName) => {
    fetchCaretaker()
    .then(() => {
      fetchTokken();
      console.log(tokken);
      sendNotification(tokken);
    })
    .catch((error) => {
      console.error("Error sending emergency alert:", error);
    });
  }
  const seniorButtons = [
    { key: 'heart', type: 'HeartRate', imageSource: require("../assets/heart-attack.png") },
    { key: 'meds', type: 'meds_senior', imageSource: require("../assets/med_reminder.png") },
    { key: 'Appointment', type: 'appoint_senior', imageSource: require("../assets/med_appoint.png") },
    { key: 'newsfeed', type: 'newsfeed', imageSource: require("../assets/newspaper.png") },
    { key: 'books', type: 'PDFList', imageSource: require("../assets/book-stack.png") },
    { key: 'careplan', type: 'viewcareplan', imageSource: require("../assets/care_plan.png") },
    { key: 'emgalert', type: 'coming', imageSource: require("../assets/emg_alert.png") },
  ];

  const caretakerButtons = [
    { key: 'heartcare', type: 'heartcare', imageSource: require("../assets/heart-attack.png") },
    { key: 'Appointment', type: 'Appointment', imageSource: require("../assets/med_appoint.png") },
    { key: 'meds', type: 'MedRem', imageSource: require("../assets/med_reminder.png") },
    { key: 'liveloc', type: 'liveloc', imageSource: require("../assets/live_loc.png") },
    { key: 'careplan', type: 'careplan', imageSource: require("../assets/care_plan.png") },
    { key: 'doctors', type: 'doctors', imageSource: require("../assets/profile.png") },

  ];
  
  const buttons = userRole === 'Senior' ? seniorButtons : caretakerButtons;


  if (loading) {
    return (
      <View style={[styles.home_container, styles.loading_container]}>
        <ActivityIndicator size="large" color="#0000ff" />
      </View>
    );
  }

  return (
    <ImageBackground
      source={require("../assets/test2.jpeg")}
      style={styles.home_background}
    >
      <View style={styles.home_container}>
      <View style={styles.home_row}>
        {generateButtons(buttons.slice(0, 2), handleButtonPress)}
      </View>
      <View style={styles.home_row}>
        {generateButtons(buttons.slice(2, 4), handleButtonPress)}
      </View>
      <View style={styles.home_row}>
        {generateButtons(buttons.slice(4, 6), handleButtonPress)}
      </View>
      <View style={styles.home_row}>
        {generateButtons(buttons.slice(6, 8), handleEmgAlert)}
      </View>
      </View>
    </ImageBackground>
  );
};

export default Home;