import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  Modal,
  TextInput,
  ScrollView,
  ActivityIndicator,
  Platform,
} from "react-native";
import {
  setDoc,
  doc,
  getDoc,
  updateDoc,
  deleteDoc,
  toDate,
} from "firebase/firestore";
import styles from "../styles/med_appoint_style";

import { collection, getDocs } from "firebase/firestore";
import DateTimePicker from '@react-native-community/datetimepicker';
import { Firebase_Auth, Firebase_Db } from "../components/firebase_access";
import { get } from "react-native/Libraries/TurboModule/TurboModuleRegistry";

const AppointScreen = ({ navigation }) => {
  var auth = Firebase_Auth;
  const user = auth.currentUser;
  const userID = user.uid;
  const [isLoading, setIsLoading] = useState(true);
  const db = Firebase_Db;
  const [modalVisible, setModalVisible] = useState(false);
  const [appointments, setAppointments] = useState([]);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);

  const [newAppointment, setNewAppointment] = useState({
    title: "",
    time: "",
    date: new Date(),
    description: "",
  });

  const handleBackButton = () => {
    navigation.navigate("Home");
  };

  const getAppointmentFromDB = async () => {
    setIsLoading(true);
    const appointsCollection = collection(db, `appoints_${userID}`);
    const appointsSnapshot = await getDocs(appointsCollection);
    const appointsData = appointsSnapshot.docs
      .map(doc => ({
        id: doc.id,
        ...doc.data(),
      }))
      .filter(appoints => appoints.date && appoints.description && appoints.time && appoints.title)
      .map(appoint => ({
        ...appoint,
        date: appoint.date.toDate(), // Convert Firebase Timestamp to Date
      }));
    setAppointments(appointsData);
  };

  const validateAppointment = () => {
    if (
      !newAppointment.title.trim() ||
      !newAppointment.time.trim() ||
      !newAppointment.description.trim()
    ) {
      alert("All Fields Required!");
      return false;
    }

    return true;
  };
  const addAppointment = async () => {
    const { title, time, date, description } = newAppointment;

    // Check if title, time, or date is empty
    if (!title || !time || !date) {
      alert("Please enter a title, time, and date for the appointment.");
      return;
    }

    // Check if the appointment date is in the past
    const currentDate = new Date();
    if (new Date(date) < currentDate) {
      alert("Please select a future date for the appointment.");
      return;
    }

    // Check if the appointment time is in the past
    const [hours, minutes] = time.split(":");
    const selectedTime = new Date(date).setHours(parseInt(hours), parseInt(minutes));
    if (selectedTime < currentDate.getTime()) {
      alert("Please select a future time for the appointment.");
      return;
    }

    // Check if the appointment clashes with existing appointments
    const appointsCollection = collection(Firebase_Db, `appoints_${userID}`);
    const appointsSnapshot = await getDocs(appointsCollection);
    const existingAppointments = appointsSnapshot.docs.map(doc => doc.data());

    console.log("Existing appointments:", existingAppointments);

    const isClash = existingAppointments.some(appointment => {
      let appointmentTime;
      if (appointment.date.seconds) {
        appointmentTime = new Date(appointment.date.seconds * 1000);
      } else {
        appointmentTime = new Date(appointment.date); 
      }
      const toMatch = new Date(newAppointment.date);

      return (
        appointmentTime.getDate() === toMatch.getDate()
        && appointmentTime.getDay() === toMatch.getDay()
        && appointmentTime.getFullYear() === toMatch.getFullYear()
        && appointmentTime.getFullYear() === toMatch.getFullYear()

      );
    });

    if (isClash) {
      alert("This appointment clashes with an existing appointment.");
      return;
    }

    await setDoc(doc(appointsCollection), newAppointment);
    alert("Appointment added successfully!");

    setNewAppointment({
      title: "",
      time: "",
      date: new Date(),
      description: "",
    });
    getAppointmentFromDB();
    setIsLoading(false);
  };


  const handleAddAppointment = () => {
    if (validateAppointment()) {
      addAppointment();

    }
  };

  useEffect(() => {
    getAppointmentFromDB();
    setIsLoading(false);
  }, []);

  const handleCardButton = () => {
    setModalVisible(true);
  };
  const handleDateChange = (event, selectedDate) => {
    if (Platform.OS === 'android') {
      selectedDate = selectedDate.getTime() + selectedDate.getTimezoneOffset() * 60000;
      selectedDate = new Date(selectedDate);
    }
    const currentDate = selectedDate || new Date();
    if (isValidDate(currentDate)) {
      setNewAppointment({ ...newAppointment, date: currentDate });
      setShowDatePicker(false);
    } else {
      alert("Invalid date selected");
    }
  };
  const handleTimeChange = (event, selectedTime) => {
    setShowTimePicker(false);
    if (selectedTime) {
      const hours = selectedTime.getHours();
      const minutes = selectedTime.getMinutes();
      const timeString = `${hours}:${minutes < 10 ? '0' : ''}${minutes} ${hours >= 12 ? 'PM' : 'AM'}`;
      console.log(timeString);
      setNewAppointment({ ...newAppointment, time: timeString });
    }
  };
  const handleDeleteAppointment = async (id) => {
    const appointsCollection = collection(db, `appoints_${userID}`);
    await deleteDoc(doc(appointsCollection, id));
    setAppointments(prevAppointments => prevAppointments.filter(appointment => appointment.id !== id));
    alert("Appointment deleted successfully!");
  };

  const isValidDate = (date) => {
    return date instanceof Date && !isNaN(date);
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={handleBackButton} style={styles.backButton}>
        <Text style={styles.backButtonText}>Back</Text>
      </TouchableOpacity>

      <View style={styles.formContainer}>
        <Text style={styles.formTitle}>Add Appointment</Text>
        <TextInput
          style={styles.input}
          placeholder="Title"
          value={newAppointment.title}
          onChangeText={(text) =>
            setNewAppointment({ ...newAppointment, title: text })
          }
        />
        <TouchableOpacity
          onPress={() => setShowTimePicker(true)}
          style={styles.pickerbutton}
        >
          <Text style={styles.pickerbuttonText}>Select Time</Text>
        </TouchableOpacity>
        {showTimePicker && (
          <DateTimePicker
            value={new Date()}
            mode="time"
            display="default"
            onChange={handleTimeChange}
          />
        )}

        <TouchableOpacity
          onPress={() => setShowDatePicker(true)}
          style={styles.pickerbutton}
        >
          <Text style={styles.pickerbuttonText}>Show Date Picker</Text>
        </TouchableOpacity>
        {showDatePicker && (
          <DateTimePicker
            value={new Date(newAppointment.date)}
            mode="date"
            display="default"
            onChange={handleDateChange}
          />
        )}
        <TextInput
          style={[styles.input, styles.descriptionInput]}
          placeholder="Description"
          value={newAppointment.description}
          onChangeText={(text) =>
            setNewAppointment({ ...newAppointment, description: text })
          }
        />
        <TouchableOpacity
          onPress={handleAddAppointment}
          style={styles.addButton}
        >
          <Text style={styles.addButtonText}>Add Appointment</Text>
        </TouchableOpacity>
      </View>

      <ScrollView>
        {isLoading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#0000ff" />
          </View>
        ) : (
          <View>
            {appointments.length === 0 ? (
              <Text style={styles.noAppointmentsText}>No appointments</Text>
            ) : (
              <View>
                {appointments.map((appointment, index) => (
                  <View key={index} style={styles.card}>
                    <Text style={styles.cardTitle}>{appointment.title}</Text>
                    <Text style={styles.cardTime}>
                      Time: {appointment.time}
                    </Text>
                    <Text style={styles.cardDate}>
                      Date: {new Date(appointment.date).toISOString().split('T')[0]}
                    </Text>
                    <Text style={styles.modalText}>
                      Description: {appointment.description}
                    </Text>

                    <TouchableOpacity onPress={() => handleDeleteAppointment(appointment.id)} style={styles.deleteButton}>
                      <Text style={styles.deleteButtonText}>Delete</Text>
                    </TouchableOpacity>
                  </View>
                ))}
              </View>
            )}
          </View>
        )}
      </ScrollView>
    </View>
  );
};

export default AppointScreen;
