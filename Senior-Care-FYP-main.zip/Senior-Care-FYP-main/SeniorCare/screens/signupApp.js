import React, { useState } from 'react';
import { View, Text, TextInput, Button, Image, ScrollView, KeyboardAvoidingView, ActivityIndicator } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import styles from '../styles/main_style';
import { createUserWithEmailAndPassword, getAuth, sendEmailVerification } from 'firebase/auth';
import { setDoc, doc } from 'firebase/firestore';
import { RadioButton } from 'react-native-paper';
import { Firebase_Auth,Firebase_Db } from "../components/firebase_access";

export default function SignupApp() {
  const navigation = useNavigation();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [age, setAge] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [errors, setErrors] = useState({});
  const [selectedRole, setSelectedRole] = useState('Senior');
  const [isLoading, setIsLoading] = useState(false);

  const auth = Firebase_Auth;
  const db = Firebase_Db;

  const validateForm = () => {
    let formErrors = {};

    if (!name) formErrors.name = 'Name is required';
    if (!email) formErrors.email = 'Email is required';
    if (!password) formErrors.password = 'Password is required';
    if (!phone) formErrors.phone = 'Phone is required';
    if (!address) formErrors.address = 'Address is required';
    if (!age) formErrors.age = 'Age is required';
    setErrors(formErrors);

    return Object.keys(formErrors).length === 0;
  };

  const createUser = () => {
    setIsLoading(true);

    createUserWithEmailAndPassword(auth, email, password).then(() => {
      sendEmailVerification(auth.currentUser)
        .then(() => {
          //alert('Verification email sent');
        })
        .catch(error => {
          console.log(error);
          alert(error);
        })
        .then(async () => {
          await setDoc(doc(db, 'users', auth.currentUser.uid), {
            email: email,
          });
          const ref = doc(db, "UserInfo", auth.currentUser.uid);
          const docRef = await setDoc(ref, { name, email, phone, address, age, selectedRole })
          setIsLoading(false);
          alert('Account Created');
          navigation.navigate('Login');
        })
    })
      .catch(error => {
        if (error.code === 'auth/email-already-in-use') {
          alert('Email Already In Use.');
        }
        else if (error.code === 'auth/invalid-email') {
          alert('Please Enter Email Correct!');
        }
        else if (error.code === 'auth/weak-password') {
          alert('Password must be > 6');
        }
        else {
          console.log(error.code);
          alert(error.code);
        }
      })
      .finally(() => {
        setIsLoading(false);
      });

  };

  const handleSubmit = () => {
    if (validateForm()) {
      createUser();
      console.log('Submitted');
      setName('');
      setEmail('');
      setPassword('');
      setAge('');
      setPhone('');
      setAddress('');
      setErrors({});
    }
  };
  return (
    <KeyboardAvoidingView style={styles.login_container}>
      <ScrollView style={styles.scrollview}>
        <View style={styles.form}>
          <Image source={require('../assets/logo.png')} style={styles.image} />

          <Text style={styles.label}>Name</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your name"
            onChangeText={(text) => setName(text)}
            value={name}
          />
          {errors.name ? <Text style={styles.errorText}>{errors.name}</Text> : null}

          <Text style={styles.label}>Email</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your email"
            onChangeText={(text) => setEmail(text)}
            value={email}
          />
          {errors.email ? <Text style={styles.errorText}>{errors.email}</Text> : null}

          <Text style={styles.label}>Password</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your password"
            onChangeText={(text) => setPassword(text)}
            value={password}
            secureTextEntry
          />
          {errors.password ? <Text style={styles.errorText}>{errors.password}</Text> : null}

          <Text style={styles.label}>Age</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your age"
            onChangeText={(text) => setAge(text)}
            value={age}
            keyboardType='numeric'
          />
          {errors.age ? <Text style={styles.errorText}>{errors.age}</Text> : null}

          <Text style={styles.label}>Phone</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your phone"
            onChangeText={(text) => setPhone(text)}
            value={phone}
            keyboardType='numeric'
          />
          {errors.phone ? <Text style={styles.errorText}>{errors.phone}</Text> : null}

          <Text style={styles.label}>Address</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your address"
            onChangeText={(text) => setAddress(text)}
            value={address}
          />
          {errors.address ? <Text style={styles.errorText}>{errors.address}</Text> : null}

          <Text style={styles.label}>Role</Text>
          <View>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <RadioButton
                value="Senior"
                status={selectedRole === 'Senior' ? 'checked' : 'unchecked'}
                onPress={() => setSelectedRole('Senior')}
              />
              <Text>Senior</Text>
            </View>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <RadioButton
                value="Caretaker"
                status={selectedRole === 'Caretaker' ? 'checked' : 'unchecked'}
                onPress={() => setSelectedRole('Caretaker')}
              />
              <Text>Caretaker</Text>
            </View>
          </View>

          {isLoading ? (
            <ActivityIndicator size="large" color="#0000ff" />
          ) : (
            <Button title="Sign Up" onPress={handleSubmit} />
          )}
        </View>
      </ScrollView>
    </KeyboardAvoidingView>

  );
}