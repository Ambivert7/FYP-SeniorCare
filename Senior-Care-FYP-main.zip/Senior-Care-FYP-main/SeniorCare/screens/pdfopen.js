import React from 'react';
import { View } from 'react-native';
import { WebView } from 'react-native-webview';
import styles from '../styles/pdf_style';

export default function PDFViewerScreen({ route }) {
  const { uri } = route.params;

  return (
    <View style={styles.pdfcontainer}>
      <WebView
        source={{ uri: uri }}
        style={{ flex: 1 }}
      />
    </View>
  );
}

