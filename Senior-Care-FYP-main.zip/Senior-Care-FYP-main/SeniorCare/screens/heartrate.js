import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, Platform, Dimensions } from 'react-native';

import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/Ionicons';
import {
  initialize,
  requestPermission,
  readRecords,
} from 'react-native-health-connect';
import styles from '../styles/heart_style';
import Svg, { Circle, G, Text as SvgText, TSpan } from 'react-native-svg';
import {
  GestureHandlerRootView,
  PanGestureHandler, State
} from 'react-native-gesture-handler';

import useBloodPressureData from '../components/bp_value';

import { Firebase_Auth, Firebase_Db } from '../components/firebase_access';
import { Timestamp } from 'firebase/firestore';
import { setDoc, doc, collection, getDocs, updateDoc } from "firebase/firestore";

import HeartRateChart from '../components/heartratechart';

const HeartRateScreen = () => {
  const [heartRate, setHeartRate] = useState(0);
  const [heartRateArray, setHeartRateArray] = useState([]);
  const { bpDia, bpSys, steps } = useBloodPressureData();
  const [bpData, setBpData] = useState([]);
  const user = Firebase_Auth.currentUser;
  const userID = user.uid;

  useEffect(() => {
    // Update bpData whenever bpDia or bpSys changes
    setBpData([
      { key: 'Diastolic', value: bpDia },
      { key: 'Systolic', value: bpSys },
    ]);
  }, [bpDia, bpSys]);

  const navigation = useNavigation(); // Initialize navigation

  useEffect(() => {
    readSampleData();
  }, []);

  useEffect(() => {
    HealthDataToFirebase();
  }, [heartRate, heartRateArray]);

  const handleGoBack = () => {
    navigation.goBack();
  };

  let lastUploadID = 0; // Initialize the lastUploadID
  let lastUploadTimestamp = 0; // Initialize the lastUploadTimestamp
  const HealthDataToFirebase = async () => {
    const currentTime = Date.now();
    const newData = {
      heartRate,
      heartRateArray,
      bpDia,
      bpSys,
      steps,
      Timestamp: Timestamp.now(),
      UploadID: ++lastUploadID, // Increment the lastUploadID for each new document
    };

    try {
      const healthDataCol = collection(Firebase_Db, `healthData_${userID}`);
      const querySnapshot = await getDocs(healthDataCol);
      const lastDoc = querySnapshot.docs[querySnapshot.docs.length - 1];

      if (lastDoc && lastDoc.exists) {
        const lastData = lastDoc.data();

        // Check if 1 hour has passed since the last upload
        const isOneHourPassed = (currentTime - lastUploadTimestamp) >= (60 * 60 * 1000);

        // Check if the new data is different from the last saved data
        const isDifferent =
          JSON.stringify(lastData.heartRateArray) !== JSON.stringify(newData.heartRateArray) ||
          JSON.stringify(lastData.heartRate) !== JSON.stringify(newData.heartRate) ||
          JSON.stringify(lastData.bpDia) !== JSON.stringify(newData.bpDia) ||
          JSON.stringify(lastData.bpSys) !== JSON.stringify(newData.bpSys) ||
          JSON.stringify(lastData.steps) !== JSON.stringify(newData.steps);

        if (isDifferent || isOneHourPassed) {
          // Update the last document
          await updateDoc(lastDoc.ref, {
            heartRate: newData.heartRate,
            heartRateArray: newData.heartRateArray,
            bpDia: newData.bpDia,
            bpSys: newData.bpSys,
            steps: newData.steps,
            Timestamp: newData.Timestamp,
          });
          console.log("Document updated successfully");
        } else {
          console.log("Data is the same and 1 hour has not passed, not updating");
        }
      } else {
        // If no previous document exists, add a new document
        await setDoc(doc(healthDataCol), newData);
        console.log("Document added successfully");
      }

      // Update the last upload timestamp
      lastUploadTimestamp = currentTime;
    } catch (error) {
      console.error("Error writing document: ", error);
    }
  };


  const readSampleData = async () => {
    // initialize the client
    const isInitialized = await initialize();

    // request permissions
    const grantedPermissions = await requestPermission([
      { accessType: 'read', recordType: 'HeartRate' },
      { accessType: 'read', recordType: 'BloodPressure' },
    ]);
    // check if granted
    const readHeartRate = () => {
      const endDate = new Date(); // Current date
      const startDate = new Date();
      startDate.setHours(startDate.getHours() - 1);

      readRecords('HeartRate', {
        timeRangeFilter: {
          operator: 'between',
          startTime: startDate.toISOString(),
          endTime: endDate.toISOString(),
        },
      }).then((results) => {
        if (results && results.length > 0) {
          const allBPMValues = [];

          results.forEach((result) => {
            if (result.samples && result.samples.length > 0) {
              const bpmValues = result.samples.map((sample) => sample.beatsPerMinute);
              allBPMValues.push(...bpmValues);
            }
          });

          if (allBPMValues.length > 0) {
            setHeartRateArray(allBPMValues);
            console.log(`All heart rate values: ${allBPMValues}`);
            const currHeartRate = allBPMValues[allBPMValues.length - 1];
            console.log(`Current heart rate: ${currHeartRate}`);
            setHeartRate(`${currHeartRate}`);
            heartRateArray.sort((a, b) => a - b);
          } else {
            alert("No BPM data found.");
            console.log("No BPM data found.");
          }
        } else {
          alert("No heart rate records found in the specified time range.");
          console.log("No heart rate records found in the specified time range.");
        }
      }).catch((error) => {
        alert("Error.");
        console.error("Error occurred:", error);
      });
    };

    readHeartRate();
  };

  useEffect(() => {
    if (Platform.OS !== 'android') {
      return;
    }

  }

  );

  const [value, setValue] = useState(100); // Initial value set to 70% of 200
  const onGestureEvent = (event) => {
    if (event.nativeEvent.state === State.END) {
      // Calculate the angle from the touch position
      const { x, y } = event.nativeEvent;
      const angle = Math.atan2(y - 130, x - 150) * (180 / Math.PI) + 180;

      // Calculate the value based on the angle
      let newValue = Math.round((angle / 360) * 200);
      if (newValue < 0) {
        newValue = 0;
      } else if (newValue > 200) {
        newValue = 200;
      }
      setValue(newValue);
    }
  };
  const renderItem = ({ item }) => (
    <View style={styles.bpItem}>
      <Text style={styles.bpmText}>{item.key}: {item.value}</Text>
    </View>
  );



  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.backButton} onPress={handleGoBack}>
        <Icon name="arrow-back" size={30} color="black" />
      </TouchableOpacity>

      <View style={styles.iconContainer}>
        <GestureHandlerRootView style={styles.container}>
          <Svg height="300" width="300">
            <Circle
              cx="150"
              cy="130"
              r="100"
              stroke="#ddd"
              strokeWidth="20"
              fill="transparent"
            />
            <Circle
              cx="150"
              cy="130"
              r="100"
              stroke="#FA8072"
              strokeWidth="20"
              strokeDasharray={`${(heartRate / 200) * 440} 628`}
              fill="transparent"
            />
            <G x="150" y="130">
              <SvgText
                x="-25"
                y="5"
                fontSize="24"
                fill="#000"
                textAnchor="middle"
              >
                {heartRate} <TSpan dx="5">   /-bpm</TSpan>
              </SvgText>
            </G>
          </Svg>
          <PanGestureHandler onGestureEvent={onGestureEvent}>
            <View style={styles.touchArea} />
          </PanGestureHandler>
        </GestureHandlerRootView>
      </View>
      <HeartRateChart heartRateArray={heartRateArray} />
      <View>

      </View>
      {/* Display Blood Pressure */}
      <View style={styles.iconContainer}>
        <View style={styles.bpContainer}>
          <Text style={styles.bpmText}>Blood Pressure:</Text>
          <Text style={styles.bpmText}>Diastolic: {bpDia}</Text>
          <Text style={styles.bpmText}>Systolic: {bpSys}</Text>
          <Text style={styles.bpmText}>Steps Count: {steps}</Text>
        </View>
      </View>

    </View>
  );
};



export default HeartRateScreen;

