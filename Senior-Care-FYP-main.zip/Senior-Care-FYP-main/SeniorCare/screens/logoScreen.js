import React, { useEffect, useState } from "react";
import {
  View,
  Image,
  ImageBackground,
  TouchableOpacity,
  Text,
} from "react-native";
import styles from "../styles/splash_style";

const LogoScreen = ({ navigation }) => {
  useEffect(()=>{
    setTimeout(()=>{
      navigation.navigate("Login");

    }, 3000)
  })

  

  return (
    <ImageBackground
      source={require("../assets/test.jpg")} // Your background image
      style={styles.background}
    >
      <View style={styles.container}>
        <Image
          source={require("../assets/logo.png")}
          style={styles.logo}
          resizeMode="contain"
        />
        
      </View>
    </ImageBackground>
  );
};



export default LogoScreen;