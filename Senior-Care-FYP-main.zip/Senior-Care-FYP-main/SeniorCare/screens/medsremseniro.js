import React, { useState, useEffect } from "react";
import { View, Text, TouchableOpacity, FlatList, ActivityIndicator, StyleSheet } from "react-native";
import {  collection, getDocs, doc, deleteDoc } from "firebase/firestore";

import styles from "../styles/med_style";
import { Firebase_Auth,Firebase_Db } from "../components/firebase_access";

const MedicationScreenSenior = ({ navigation }) => {
  const [reminders, setReminders] = useState([]);
  const [loading, setLoading] = useState(true);
  const auth = Firebase_Auth;
  const user = auth.currentUser;
  const userID = user.uid;
  const db = Firebase_Db;
  const [caretaker, setCaretaker] = useState('');

  useEffect(() => {
    fetchCaretaker();

}, []);

  const fetchCaretaker = async () => {
    const querySnapshot = await getDocs(collection(db, "connections"));
    querySnapshot.forEach((doc) => {
      if (doc.id === userID) {
        const caretaker = doc.data().connectionDetails;
        setCaretaker(caretaker);
        fetchReminders(caretaker);
      }
    });
  }

  const fetchReminders = async (caretaker) => {
    const remindersCollection = collection(db, `reminders_${caretaker}`);

    const remindersSnapshot = await getDocs(remindersCollection);

    if (remindersSnapshot.empty) {
      alert("No reminders found");
      setLoading(false);
      return;
    }

    const remindersData = remindersSnapshot.docs
      .filter(doc => doc.exists())
      .map(doc => ({
        id: doc.id,
        ...doc.data(),
      }))
      .filter(reminder => reminder.medicationName && reminder.reminderTime);
    setReminders(remindersData);
    setLoading(false);
  };

  const handleBackButton = () => {
    navigation.navigate("Home");
  };

  const handleDeleteReminder = async (id) => {
    setLoading(true);
    const remindersCollection = collection(db, `reminders_${caretaker}`);
    await deleteDoc(doc(remindersCollection, id));

    const updatedRemindersSnapshot = await getDocs(remindersCollection);
    const updatedRemindersData = updatedRemindersSnapshot.docs
      .filter(doc => doc.exists())
      .map(doc => ({
        id: doc.id,
        ...doc.data(),
      }))
      .filter(reminder => reminder.medicationName && reminder.reminderTime);

    setReminders(updatedRemindersData);
    setLoading(false);
  };

  return (
    <View style={styles.seniormedcontainer}>
      <TouchableOpacity onPress={handleBackButton} style={styles.seniormedbackButton}>
        <Text style={styles.seniormedbackButtonText}>Back</Text>
      </TouchableOpacity>
      <Text style={styles.title}>Today's Medicines</Text>
      {loading ? (
        <ActivityIndicator style={styles.seniormedloading} size="large" color="#0000ff" />
      ) : (
        <FlatList
          data={reminders}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <TouchableOpacity style={styles.seniormedreminderItem} onPress={() => handleDeleteReminder(item.id)}>
              <Text style={styles.seniormedmedicationName}>{item.medicationName}</Text>
              <Text style={styles.seniormedreminderTime}>{item.reminderTime}</Text>
              <Text style={styles.seniormeddeleteButton}>Confirm</Text>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
};

    

export default MedicationScreenSenior;
