import React, { useState, useEffect } from "react";
import { View, Text, TextInput, TouchableOpacity, FlatList, ActivityIndicator } from "react-native";
import styles from "../styles/med_style";
import DateTimePicker from '@react-native-community/datetimepicker';
import {  setDoc, doc, deleteDoc } from "firebase/firestore";
import { collection, getDocs } from "firebase/firestore";

import { Firebase_Auth,Firebase_Db } from "../components/firebase_access";


const MedicationScreen = ({ navigation }) => {
  const [medicationName, setMedicationName] = useState("");
  const [reminderTime, setReminderTime] = useState("");
  const [reminders, setReminders] = useState([]);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const user = Firebase_Auth.currentUser;
  const userID = user.uid;
  const [loading, setLoading] = useState(true); // Track loading state


  useEffect(() => {
    const fetchReminders = async () => {
      const db = Firebase_Db;
      const remindersCollection = collection(db, `reminders_${userID}`);
      
      // Check if the collection exists
      const remindersSnapshot = await getDocs(remindersCollection);
      if (remindersSnapshot.empty) {
        // Collection does not exist, create it
        await setDoc(doc(db, `reminders_${userID}`, 'placeholder'), { placeholder: true });
      }
  
      // Fetch reminders from the collection
      const remindersSnapshotAfterCreation = await getDocs(remindersCollection);
      const remindersData = remindersSnapshotAfterCreation.docs
        .filter(doc => doc.exists()) // Filter out non-existing documents
        .map(doc => ({
          id: doc.id,
          ...doc.data(),
        }))
        .filter(reminder => reminder.medicationName && reminder.reminderTime);
      setReminders(remindersData);
      setLoading(false); 
    };
    fetchReminders();
  
    return () => {
    };
  }, []);
  

  const handleBackButton = () => {
    navigation.navigate("Home");
  };

  const handleSaveReminder = async () => {
    setLoading(true);
  
    // Check if medicationName or reminderTime is empty
    if (!medicationName || !reminderTime) {
      alert("Please enter a medication name and select a reminder time.");
      setLoading(false);
      return;
    }
  
    const newReminder = {
      medicationName,
      reminderTime,
    };
  
    const remindersCollection = collection(Firebase_Db, `reminders_${userID}`);
  
    // Check if there is already a reminder with the same medication name and reminder time
    const existingReminder = reminders.find(
      (reminder) =>
        reminder.medicationName === medicationName ||
        reminder.reminderTime === reminderTime
    );
  
    if (existingReminder) {
      // Alert the user that a reminder with the same medication name and reminder time already exists
      alert("A reminder with the same medication name or reminder time already exists.");
      setLoading(false);
      return;
    }
  
    // Check if there is already a reminder with the same medication name but different reminder time
    const existingReminderWithSameName = reminders.find(
      (reminder) =>
        reminder.medicationName === medicationName &&
        reminder.reminderTime !== reminderTime
    );
  
    if (existingReminderWithSameName) {
      // If a reminder with the same medication name but different reminder time exists, update its reminder time
      await setDoc(doc(remindersCollection, existingReminderWithSameName.id), { reminderTime });
    } else {
      // If no reminder with the same medication name exists, add a new reminder
      await setDoc(doc(remindersCollection), newReminder);
    }
  
    // Fetch updated list of reminders
    const updatedRemindersSnapshot = await getDocs(remindersCollection);
    const updatedRemindersData = updatedRemindersSnapshot.docs
      .filter((doc) => doc.exists())
      .map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }))
      .filter((reminder) => reminder.medicationName && reminder.reminderTime);
  
    setReminders(updatedRemindersData);
  
    setLoading(false);
  
    setMedicationName("");
    setReminderTime("");
  };
  
  

  const handleTimeChange = (event, selectedTime) => {
    if (selectedTime) {
      const hours = selectedTime.getHours();
      const minutes = selectedTime.getMinutes();
      const timeString = `${hours}:${minutes < 10 ? '0' : ''}${minutes} ${hours >= 12 ? 'PM' : 'AM'}`;
      setReminderTime(timeString);
      setShowTimePicker(false); // Close the time picker after selecting a time
    }
  };

  const handleDeleteReminder = async (id) => {
    setLoading(true);
    const remindersCollection = collection(Firebase_Db, `reminders_${userID}`);
    await deleteDoc(doc(remindersCollection, id));
  
    // Fetch updated list of reminders after deleting
    const updatedRemindersSnapshot = await getDocs(remindersCollection);
    const updatedRemindersData = updatedRemindersSnapshot.docs
      .filter(doc => doc.exists())
      .map(doc => ({
        id: doc.id,
        ...doc.data(),
      }))
      .filter(reminder => reminder.medicationName && reminder.reminderTime);
    
    setReminders(updatedRemindersData);
    setLoading(false);

  };
  
  

  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={handleBackButton} style={styles.backButton}>
        <Text style={styles.backButtonText}>Back</Text>
      </TouchableOpacity>
      <Text style={styles.label}>Medication Name:</Text>
      <TextInput
        style={styles.input}
        value={medicationName}
        onChangeText={(text) => setMedicationName(text)}
      />

      <TouchableOpacity
        onPress={() => setShowTimePicker(true)}
        style={styles.pickerbutton}
      >
        <Text style={styles.pickerbuttonText}>Select Time</Text>
      </TouchableOpacity>
      {showTimePicker && (
        <DateTimePicker
          value={new Date()} // Use a default value or the current time
          mode="time"
          display="default"
          onChange={handleTimeChange}
        />
      )}

      <TouchableOpacity style={styles.saveButton} onPress={handleSaveReminder}>
        <Text style={styles.saveButtonText}>Save Reminder</Text>
      </TouchableOpacity>

      {loading ? (
        <ActivityIndicator style={styles.loading} size="large" color="#0000ff" />
      ) : (
        <FlatList
          data={reminders}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.reminderItem}>
              <Text>{item.medicationName}</Text>
              <Text>{item.reminderTime}</Text>
              <TouchableOpacity onPress={() => handleDeleteReminder(item.id)}>
                <Text style={styles.deleteButton}>Delete</Text>
              </TouchableOpacity>
            </View>
          )}
        />
      )}
    </View>
  );
};

export default MedicationScreen;
