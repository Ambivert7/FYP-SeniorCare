import React from 'react';
import { TouchableOpacity, Image } from 'react-native';
import styles from '../styles/main_style';

const ButtonCard = ({ onPress, imageSource }) => (
  <TouchableOpacity
    style={[styles.home_buttonCard, { backgroundColor: "#fff" }]}
    onPress={onPress}
  >
    <Image
      source={imageSource}
      style={styles.home_iconImage}
    />
  </TouchableOpacity>
);

const generateButtons = (buttons, handler) => (
  buttons.map((button) => (
    <ButtonCard
      key={button.key}
      onPress={() => handler(button.type)}
      imageSource={button.imageSource}
    />
  ))
);

export { ButtonCard, generateButtons };
