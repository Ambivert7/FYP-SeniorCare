import SMTPMailer from 'react-native-smtp-mailer';

const SMTP_CONFIG = {
  host: 'smtp.gmail.com',
  port: '465',
  username: 'djhani36@gmail.com',
  password: 'avdbehovxirmbncf',
  secure: true,
};
const sendEmail = async (email, otp) => {
    try {
      const response = await SMTPMailer.sendMail({
        mailhost: SMTP_CONFIG.host,
        port: SMTP_CONFIG.port,
        ssl: true,
        username: SMTP_CONFIG.username,
        password: SMTP_CONFIG.password,
        from: SMTP_CONFIG.username,
        recipients: email,
        subject: 'Your OTP',
        htmlBody: `<p>Your OTP is ${otp}</p>`,
      });
  
      console.log('Email sent:', response);
      return true;
    } catch (error) {
      console.error('Failed to send email:', error);
      return false;
    }
  };
  

  export { sendEmail };
