import { setDoc, doc } from 'firebase/firestore';
import { Firebase_Auth, Firebase_Db } from '../components/firebase_access';
import * as Location from 'expo-location';

export const sendToFirebase = async () => {
  const userId = Firebase_Auth.currentUser.uid;
  if (!userId) {
    console.error('User not logged in');
    return;
  }
  
  try {
    let location = await Location.getCurrentPositionAsync({});
    if (location && location.coords.latitude && location.coords.longitude) {
      const latitude = location.coords.latitude;
      const longitude = location.coords.longitude;
      
      await setDoc(doc(Firebase_Db, 'location', userId), {
        latitude: latitude,
        longitude: longitude,
      });
      
      console.log("Location sent to Firebase:", latitude, longitude);
    } else {
      console.log("Failed to get current location.");
    }
  } catch (error) {
    console.warn("Error sending location to Firebase:", error);
  }
};