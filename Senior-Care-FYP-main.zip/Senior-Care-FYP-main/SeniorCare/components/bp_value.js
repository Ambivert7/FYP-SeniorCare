import { useState, useEffect } from 'react';
import { initialize, requestPermission, readRecords } from 'react-native-health-connect';

const useBloodPressureData = () => {
  const [bpDia, setBPDia] = useState(0);
  const [bpSys, setBPSys] = useState(0);
  const [steps, setSteps] = useState(0);

  useEffect(() => {
    const readBP = async () => {
      const endDate = new Date();
      const startDate = new Date();
      startDate.setHours(startDate.getHours() - 1);
      const isInitialized = await initialize();

      const grantedPermissions = await requestPermission([
        { accessType: 'read', recordType: 'BloodPressure' },
        { accessType: 'read', recordType: 'Steps' },

      ]);

      readRecords('BloodPressure', {
        timeRangeFilter: {
          operator: 'between',
          startTime: startDate.toISOString(),
          endTime: endDate.toISOString(),
        },
      }).then((result) => {
        if (
          result &&
          result.length > 0 &&
          result[0].diastolic &&
          result[0].diastolic.inMillimetersOfMercury &&
          result[0].systolic &&
          result[0].systolic.inMillimetersOfMercury
        ) {
          const diastolicValue = result[0].diastolic.inMillimetersOfMercury;
          const systolicValue = result[0].systolic.inMillimetersOfMercury;

          setBPDia(diastolicValue);
          setBPSys(systolicValue);
        } else {
          console.log("Diastolic Blood Pressure not found in the result.");
        }
      }).catch((error) => {
        console.error("Error occurred:", error);
      });
    };
    readSteps = async () => {
      const endDate = new Date(); // Current date
      const startDate = new Date();
      startDate.setHours(startDate.getHours() - 1);
      
      const steps = await readRecords('Steps', { timeRangeFilter: {
        operator: 'between',
        startTime: startDate.toISOString(),
        endTime: endDate.toISOString(),
      } });
      const totalSteps = steps.reduce((sum, cur) => sum + cur.count, 0);
      setSteps(totalSteps);
    }
    
    readBP();
    readSteps();
  }, []);

  return { bpDia, bpSys ,steps};
};

export default useBloodPressureData;
