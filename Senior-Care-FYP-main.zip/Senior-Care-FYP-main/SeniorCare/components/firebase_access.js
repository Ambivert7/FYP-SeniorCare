import { firebaseConfig } from '../firebase-config';
import { initializeApp } from 'firebase/app';
import { getFirestore } from "firebase/firestore";
import { initializeAuth, getReactNativePersistence } from 'firebase/auth';
import ReactNativeAsyncStorage from '@react-native-async-storage/async-storage';

const Firebase_App = initializeApp(firebaseConfig);
const Firebase_Auth = initializeAuth(Firebase_App, {
    persistence: getReactNativePersistence(ReactNativeAsyncStorage)
  });
const Firebase_Db = getFirestore(Firebase_App);

const Firebase_User_Id = Firebase_Auth.currentUser ? Firebase_Auth.currentUser.uid : null;

export { Firebase_App, Firebase_Auth, Firebase_Db };