import React from 'react';
import { View } from 'react-native';
import { BarChart } from 'react-native-chart-kit';
import { Text, StyleSheet } from 'react-native';

const HeartRateChart = ({ heartRateArray }) => {
  const data = {
    labels: [''],
    datasets: [
      {
        data: heartRateArray.slice(-60), 
        colors: [
          (opacity = 1) => `rgba(255, 0, 0, ${opacity})`, // Red color for bars
          (opacity = 1) => `rgba(0, 0, 255, ${opacity})`, // Blue color for bars
        ],
      },
    ],
  };

  // Sort the heart rate values to split them between top and bottom bars
  const sortedData = heartRateArray.slice(-60).sort((a, b) => a - b);

  // Split the sorted data into top and bottom parts
  const topData = sortedData.slice(0, Math.ceil(sortedData.length / 2));
  const bottomData = sortedData.slice(Math.ceil(sortedData.length / 2));

  // Adjust the height of the chart based on the number of bars
  const chartHeight = Math.max(topData.length, bottomData.length) * 50;

  return (
    <View>
      <BarChart
        data={data}
        width={350}
        height={150}
        yAxisSuffix=" bpm"
        chartConfig={{
          backgroundColor: '#ffffff',
          backgroundGradientFrom: '#ffffff',
          backgroundGradientTo: '#ffffff',
          decimalPlaces: 0,
          color: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
          labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
          style: {
            borderRadius: 16, // Set the border radius for rounded corners
          },
        }}
        style={{
          marginVertical: 8,
          borderRadius: 16, // Set the border radius for rounded corners
        }}
        verticalLabelRotation={0}
      />
      <View style={styles.labelContainer}>
        <Text style={styles.label}>~ Last Hour Data</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
    labelContainer: {
        backgroundColor: '#f0f0f0', 
        padding: 8, 
        borderRadius: 8, 
        marginTop: 10,
      },
      label: {
        textAlign: 'center',
        fontSize: 16,
      },
});

export default HeartRateChart;
