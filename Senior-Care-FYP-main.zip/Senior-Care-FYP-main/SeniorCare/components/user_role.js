import { collection, getDocs } from "firebase/firestore";
import { Firebase_Db } from "./firebase_access";

const getUserRole = async (userID) => {
    try {
      const querySnapshot = await getDocs(collection(Firebase_Db, "UserInfo"));
      let role = null;
      querySnapshot.forEach((doc) => {
        if (doc.id === userID) {
          const data = doc.data();
          role = data.selectedRole;
          console.log(role);
        }
      });
      return role;
    } catch (error) {
      console.error("Error fetching user role:", error);
    }
};

export default getUserRole;
