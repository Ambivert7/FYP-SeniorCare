import axios from 'axios';


const sendNotification = async (tokken) => {

    const SERVER_KEY = 'AAAAR2xOolY:APA91bF-8jRtVpnuWAyBtSRxJiq6ZYuEDYJdmsciempKOIWA9bIMm7viYqPooyH-IpfnsVGNNKYQW1d8ukDHMowWqL1aFqeSFNF3Z2Kesbc4ikcYiNLi1Gv10UPKGZkz4YPkDbSRgFjm'
    const message = {
        notification: {
            title: 'Emergency Alert',
            body: 'Please check on Senior Immediately.',
        },
        data: {
            customKey: 'customValue',
        },
        // Add the target FCM token
        to: tokken,
    };

    try {
        const response = await axios.post('https://fcm.googleapis.com/fcm/send', message, {
            headers: {
                Authorization: `key=${SERVER_KEY}`,
                'Content-Type': 'application/json',
            },
        });
        alert('Notification sent if tokken is correct');
        console.log('Notification sent:', response.data);
    } catch (error) {
        console.error('Error sending notification:', error);
    }
};



export { sendNotification };
