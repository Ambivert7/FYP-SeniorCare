import React, { useEffect } from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Ionicons } from "@expo/vector-icons";

import Home from "./screens/home";
import SettingsScreen from "./screens/setting";
import ProfileScreen from "./screens/profile";
import LogoScreen from "./screens/logoScreen";
import LoginApp from "./screens/loginApp";
import SignupApp from "./screens/signupApp";
import HeartRateScreen from "./screens/heartrate";
import AppointScreen from "./screens/appointScreen";
import ComingSoon from "./screens/comingSoon";
import MedicationScreen from "./screens/addmed";
import MapScreen from "./screens/livelocation";
import NewsScreen from "./screens/newfeedmain";
import PDFListScreen from "./screens/pdfselect";
import PDFViewerScreen from "./screens/pdfopen";
import MedicationScreenSenior from "./screens/medsremseniro";
import AppointScreenSenior from "./screens/appointSenior";
import CarePlanScreen from "./screens/careplan";
import ViewCarePlanScreen from "./screens/careplanSenior";
import HeartRateScreenCare from "./screens/heartrate_senior";
import DoctorListScreen from "./screens/doctor";

import * as TaskManager from 'expo-task-manager';
import { sendToFirebase } from './components/sentofirebase';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

TaskManager.defineTask('sendLocationToFirebase', async ({ data, error }) => {
  if (error) {
    console.error('Background location task error:', error);
    return;
  }
  await sendToFirebase();
  console.log('Location sent to Firebase');
});


function MyTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;

          if (route.name === "DashBoard") {
            iconName = focused ? "home" : "home-outline";
          } else if (route.name === "Profile") {
            iconName = focused ? "person" : "person-outline";
          } else if (route.name === "Settings") {
            iconName = focused ? "settings" : "settings-outline";
          }

          // Return the icon component
          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: "tomato",
        tabBarInactiveTintColor: "gray",
      })}
    >
      <Tab.Screen name="DashBoard" component={Home} />
      <Tab.Screen name="Profile" component={ProfileScreen} />
      <Tab.Screen name="Settings" component={SettingsScreen} />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Initial">
        <Stack.Screen
          name="Initial"
          component={LogoScreen}
          options={{
            headerShown: false,
          }}
        />
        <Stack.Screen name="Login" component={LoginApp} 
        options={{
          headerShown: false,
        }}
        />
        <Stack.Screen name="Signup" component={SignupApp} />
        <Stack.Screen
          name="Home"
          component={MyTabs}
          options={{
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="HeartRate"
          component={HeartRateScreen}
          options={{
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="Appointment"
          component={AppointScreen}
          options={{
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="MedRem"
          component={MedicationScreen}
          options={{
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="liveloc"
          component={MapScreen}
          options={{
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="coming"
          component={ComingSoon}
          options={{
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="newsfeed"
          component={NewsScreen}
          options={{
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="meds_senior"
          component={MedicationScreenSenior}
          options={{
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="appoint_senior"
          component={AppointScreenSenior}
          options={{
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="careplan"
          component={CarePlanScreen}
          options={{
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="viewcareplan"
          component={ViewCarePlanScreen}
          options={{
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="heartcare"
          component={HeartRateScreenCare}
          options={{
            headerShown: false,
          }}
        /><Stack.Screen
        name="doctors"
        component={DoctorListScreen}
        options={{
          headerShown: false,
        }}
      />
        <Stack.Screen name="PDFList" component={PDFListScreen} options={{
            headerShown: false,
          }}/>
        <Stack.Screen name="PDFViewer" component={PDFViewerScreen} />

      </Stack.Navigator>
    </NavigationContainer>
  );
}