import { StyleSheet } from "react-native";

const styles = StyleSheet.create({
    home_background: {
      flex: 1,
      resizeMode: "cover", // or 'stretch' as per your preference
    },
    home_container: {
      flex: 1,
      paddingHorizontal: 20,
      paddingTop: 20,
    },
    home_row: {
      flexDirection: "row",
      justifyContent: "space-between",
      marginBottom: 20,
    },
    home_buttonCard: {
      width: "48%", // Adjust as needed to fit two buttons in a row
      height: 120,
      justifyContent: "center",
      alignItems: "center",
      borderRadius: 60,
      // elevation and shadow properties removed
    },
    home_buttonText: {
      fontSize: 16,
      color: "#fff",
    },
    home_iconImage: {
      width: 60,
      height: 60,
    },
    profile_container: {
        flex: 1,
        padding: 20,
        backgroundColor: "#f8f8f8",
        alignItems: "center",
      },
    profileImageContainer: {
        width: 120,
        height: 120,
        borderRadius: 60,
        backgroundColor: "#000000",
        justifyContent: "center",
        alignItems: "center",
        marginBottom: 20,
      },
    profileImageText: {
        fontSize: 48,
        color: "#fff",
      },
    profileInfo: {
        backgroundColor: "#fff",
        padding: 20,
        borderRadius: 10,
        marginBottom: 20,
        width: "100%",
      },
    infoItem: {
        marginBottom: 15,
      },
    profile_label: {
        fontSize: 16,
        fontWeight: "bold",
        color: "#333",
      },
      info: {
        fontSize: 16,
        color: "#666",
      },
      editButton: {
        backgroundColor: "green",
        paddingVertical: 12,
        paddingHorizontal: 20,
        borderRadius: 5,
        marginTop: 20,
      },
      editButtonText: {
        color: "#fff",
        fontSize: 16,
        fontWeight: "bold",
      },
      logoutButton: {
        backgroundColor: "#ff4500",
        paddingVertical: 12,
        paddingHorizontal: 20,
        borderRadius: 5,
        marginTop: 20,
      },
      logoutButtonText: {
        color: "#fff",
        fontSize: 16,
        fontWeight: "bold",
      },
      login_container: {
        flex: 1,
        justifyContent: 'center',
        paddingHorizontal: 20,
        backgroundColor: '#f5f5f5',
      },
      form: {
        backgroundColor: 'white',
        padding: 20,
        borderRadius: 10,
        shadowColor: 'black',
        shadowOffset: {
          width: 0,
          height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
      },
      label: {
        fontSize: 16,
        marginBottom: 5,
        fontWeight: 'bold',
      },
      input: {
        height: 40,
        borderColor: '#ddd',
        borderWidth: 1,
        marginBottom: 15,
        padding: 10,
        borderRadius: 5,
      },
      image: {
        width: 200,
        height: 200,
        alignSelf: 'center',
        marginBottom: 50,
      },
      errorText: {
        color: 'red',
        marginBottom: 10,
      },
      button: {
        alignItems: 'center',
        justifyContent: 'center',
        height: 40,
        borderRadius: 5,
        marginBottom: 10,
      },
      buttonText: {
        color: 'white',
        fontSize: 16,
        fontWeight: 'bold',
      },
      greenButton: {
        backgroundColor: '#3CB371',
      },
      redButton: {
        backgroundColor: '#FA8072',
      },
      blueButton: {
        backgroundColor: '#87CEEB',
      },
      signupButtonContainer: {
        marginTop: 10,
      },
      set_input: {
        width: '80%',
        height: 50,
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 10,
        paddingHorizontal: 15,
        marginBottom: 20,
        fontSize: 16,
        color: '#333',
      },
      set_button: {
        width: '80%',
        height: 50,
        backgroundColor: '#007bff',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 10,
      },
      set_buttonText: {
        fontSize: 18,
        color: '#fff',
      },
  });

  export default styles;