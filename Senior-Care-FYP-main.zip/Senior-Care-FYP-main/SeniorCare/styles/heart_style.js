import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
    container: {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
      marginTop: 50,
    },
    backButton: {
      position: 'absolute',
      top: 20,
      left: 10,
      zIndex: 1,
      padding: 10,
    },
    iconContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 20,
    },
    heartIcon: {
      width: 50,
      height: 50,
      marginRight: 10,
    },
    heartRateContainer: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    bpContainer: {
      marginTop:20,
      padding:10,
      flexDirection: 'col',
      alignItems: 'center',
    },
    heartRateValue: {
      fontSize: 36,
      fontWeight: 'bold',
      marginRight: 5,
    },
    bpmText: {
      fontSize: 18,
    },
    addButton: {
      backgroundColor: '#FA8072',
      paddingVertical: 10,
      paddingHorizontal: 20,
      borderRadius: 5,
      marginTop: 20,
    },
    addButtonText: {
      color: 'white',
      fontSize: 16,
      fontWeight: 'bold',
    },
    readingContainer: {
      marginTop: 20,
      padding: 10,
      borderWidth: 1,
      borderColor: 'gray',
      borderRadius: 5,
    },
    touchArea: {
      position: 'absolute',
      width: 300,
      height: 300,
      backgroundColor: 'transparent',
    },
    
  });

  export default styles;