import { StyleSheet,StatusBar } from "react-native";

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f0f0f0',
        padding: 16,
    },
    backButton: {
        marginBottom: 16,
        padding: 10,
        backgroundColor: '#ccc',
        borderRadius: 8,
    },
    backButtonText: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#333',
    },
    item: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 10,
        borderBottomWidth: 1,
        borderBottomColor: '#ccc',
    },
    thumbnail: {
        width: 50,
        height: 50,
        borderRadius: 8,
        marginRight: 10,
    },
    title: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#333',
    },
    pdfcontainer: {
        flex: 1,
        backgroundColor: '#fff',
    },
    newscontainer: {
        flex: 1,
        backgroundColor: '#fff',
        paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0,
      },
      newsarticleContainer: {
        padding: 10,
        borderBottomWidth: 1,
        borderBottomColor: '#ddd',
      },
      newsarticleTitle: {
        fontSize: 18,
        fontWeight: 'bold',
      },
      newsarticleDescription: {
        fontSize: 14,
        color: '#666',
      },
      newsarticleImage: {
        width: '100%',
        height: 200,
        resizeMode: 'cover',
        marginBottom: 10,
      },
      newsbackButton: {
        position: 'absolute',
        top: 16,
        left: 16,
        backgroundColor: 'rgba(255, 255, 255, 0.8)',
        padding: 8,
        borderRadius: 8,
        zIndex: 1000,
      },
      newsbackButtonText: {
        fontWeight: 'bold',
      },
});

export default styles;