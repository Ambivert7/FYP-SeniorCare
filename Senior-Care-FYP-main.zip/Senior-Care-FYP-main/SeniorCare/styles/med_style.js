import { StyleSheet } from "react-native";

const styles = StyleSheet.create({
    container: {
      flex: 1,
      paddingTop: 50,
      paddingHorizontal: 20,
    },
    label: {
      fontSize: 16,
      marginBottom: 8,
    },
    input: {
      height: 40,
      borderColor: "gray",
      borderWidth: 1,
      marginBottom: 16,
      paddingHorizontal: 8,
    },
    timePickerButton: {
      height: 40,
      borderColor: "gray",
      borderWidth: 1,
      justifyContent: "center",
      alignItems: "center",
      marginBottom: 16,
    },
    timePickerButtonText: {
      fontSize: 16,
    },
    saveButton: {
      backgroundColor: "#3498db",
      height: 40,
      justifyContent: "center",
      alignItems: "center",
      borderRadius: 8,
    },
    saveButtonText: {
      color: "#fff",
      fontSize: 16,
    },
    reminderItem: {
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      borderColor: "#ddd",
      borderWidth: 1,
      padding: 8,
      marginVertical: 4,
      borderRadius: 8,
    },
    deleteButton: {
      color: "red",
      marginLeft: 8,
    },
    backButton: {
      position: "absolute",
      top: 10,
      left: 10,
      padding: 10,
      zIndex: 1,
    },
    backButtonText: {
      fontSize: 16,
      fontWeight: "bold",
      color: "#3498db",
    },
    pickerbutton: {
      backgroundColor: '#90EE90',
      padding: 10,
      borderRadius: 5,
      marginTop: 10,
      marginBottom: 10,
      alignItems: 'center',
    },
    pickerbuttonText: {
      color: 'white',
      fontSize: 16,
    },
    seniormedcontainer: {
      flex: 1,
      padding: 20,
      backgroundColor: "#fff",
    },
    seniormedbackButton: {
      padding: 10,
      marginBottom: 20,
      backgroundColor: "#f9f9f9",
      borderRadius: 5,
      alignSelf: "flex-start",
    },
    seniormedbackButtonText: {
      fontSize: 16,
      fontWeight: "bold",
      color: "#333",
    },
    seniormedtitle: {
      fontSize: 24,
      fontWeight: "bold",
      marginBottom: 20,
      color: "#333",
    },
    seniormedreminderItem: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      padding: 10,
      marginBottom: 10,
      backgroundColor: "#f9f9f9",
      borderRadius: 5,
      elevation: 3, // Add elevation for a shadow effect
    },
    seniormedmedicationName: {
      fontSize: 16,
      fontWeight: "bold",
      color: "#333",
    },
    seniormedreminderTime: {
      fontSize: 14,
      color: "#666",
    },
    seniormeddeleteButton: {
      fontSize: 14,
      color: "#4CAF50",
    },
    seniormedloading: {
      marginTop: 20,
    },
  });

export default styles;