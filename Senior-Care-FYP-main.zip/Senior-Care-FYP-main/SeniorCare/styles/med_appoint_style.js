import { StyleSheet } from "react-native";

const styles = StyleSheet.create({
    container: {
      flex: 1,
      paddingTop: 50,
      paddingHorizontal: 20,
      backgroundColor: "#fff",
    },
    backButton: {
      position: "absolute",
      top: 10,
      left: 10,
      padding: 10,
      zIndex: 1,
    },
    backButtonText: {
      fontSize: 16,
      fontWeight: "bold",
      color: "#3498db",
    },
    card: {
      backgroundColor: "#f9f9f9",
      padding: 20,
      borderRadius: 8,
      marginBottom: 20,
    },
    cardTitle: {
      fontSize: 20,
      fontWeight: "bold",
      marginBottom: 10,
    },
    cardTime: {
      fontSize: 16,
      marginBottom: 5,
    },
    cardDate: {
      fontSize: 16,
      marginBottom: 10,
    },
    cardButton: {
      backgroundColor: "#3498db",
      padding: 10,
      borderRadius: 5,
      alignItems: "center",
    },
    cardButtonText: {
      color: "#fff",
      fontSize: 16,
    },
    centeredView: {
      flex: 1,
      justifyContent: "center",
      alignItems: "center",
      backgroundColor: "rgba(0, 0, 0, 0.5)",
    },
    modalView: {
      backgroundColor: "#fff",
      borderRadius: 8,
      padding: 20,
      width: "80%",
      alignItems: "center",
    },
    formContainer: {
      backgroundColor: "#f9f9f9",
      padding: 20,
      borderRadius: 8,
      marginBottom: 20,
    },
    formTitle: {
      fontSize: 20,
      fontWeight: "bold",
      marginBottom: 10,
      textAlign: "center",
    },
    input: {
      backgroundColor: "#fff",
      borderWidth: 1,
      borderColor: "#ccc",
      borderRadius: 5,
      padding: 10,
      marginBottom: 10,
    },
    descriptionInput: {
      height: 100,
      textAlignVertical: "top",
    },
    addButton: {
      backgroundColor: "#3498db",
      padding: 10,
      borderRadius: 5,
      alignItems: "center",
    },
    addButtonText: {
      color: "#fff",
      fontSize: 16,
    },
    modalContainer: {
      flex: 1,
      justifyContent: "center",
      alignItems: "center",
      backgroundColor: "rgba(0, 0, 0, 0.5)",
    },
    modalContent: {
      backgroundColor: "#fff",
      borderRadius: 8,
      padding: 20,
      width: "80%",
      alignItems: "center",
    },
    modalTitle: {
      fontSize: 24,
      fontWeight: "bold",
      marginBottom: 10,
    },
    modalText: {
      fontSize: 18,
      marginBottom: 10,
    },
    closeButton: {
      backgroundColor: "#3498db",
      padding: 10,
      borderRadius: 5,
      marginTop: 20,
    },
    closeButtonText: {
      color: "#fff",
      fontSize: 16,
      textAlign: "center",
    },
    deleteButton: {
      backgroundColor: "#e74c3c",
      padding: 10,
      borderRadius: 5,
      alignItems: "center",
      marginTop: 5,
    },
    deleteButtonText: {
      color: "#fff",
      fontSize: 16,
    },
    loadingContainer: {
      flex: 1,
      justifyContent: "center",
      alignItems: "center",
    },
    loadingText: {
      fontSize: 20,
      fontWeight: "bold",
      marginTop: 10,
    },
    noAppointmentsText: {
      fontSize: 18,
      fontWeight: "bold",
      color: "gray",
      textAlign: "center",
      marginTop: 20,
    },
    pickerbutton: {
      backgroundColor: '#90EE90',
      padding: 10,
      borderRadius: 5,
      marginTop: 10,
      marginBottom: 10,
      alignItems: 'center',
    },
    pickerbuttonText: {
      color: 'white',
      fontSize: 16,
    },
    title: {
      fontSize: 24,
      fontWeight: 'bold',
      marginBottom: 20,
  },
  });
export default styles;