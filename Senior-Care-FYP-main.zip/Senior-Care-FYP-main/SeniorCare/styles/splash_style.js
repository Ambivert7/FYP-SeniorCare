import { StyleSheet } from "react-native";

const styles = StyleSheet.create({
    background: {
      flex: 1,
      resizeMode: "cover", // or 'stretch' if necessary
      justifyContent: "center",
    },
    container: {
      flex: 1,
      justifyContent: "center",
      alignItems: "center",
      backgroundColor: "rgba(255, 255, 255, 0.5)", // Fallback color (light grey with transparency)
    },
    logo: {
      width: 200,
      height: 200,
      marginBottom: 30,
    },
    buttonsContainer: {
      justifyContent: "center",
      alignItems: "center",
    },
    button: {
      width: 250,
      height: 50,
      margin: 10,
      borderRadius: 8,
      backgroundColor: "#3498db",
      justifyContent: "center",
      alignItems: "center",
    },
    greenButton: {
      backgroundColor: "#3CB371",
    },
    redButton: {
      backgroundColor: "#FA8072",
    },
    buttonText: {
      color: "#fff",
      fontSize: 16,
    },
  });

export default styles;