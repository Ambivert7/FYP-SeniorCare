import { StyleSheet } from "react-native";

const styles = StyleSheet.create({
    container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
    },
    backButton: {
      position: 'absolute',
      top: 16,
      left: 16,
      backgroundColor: 'rgba(255, 255, 255, 0.8)',
      padding: 8,
      borderRadius: 8,
      zIndex: 1000,
    },
    backButtonText: {
      fontWeight: 'bold',
    },
  });

  export default styles;