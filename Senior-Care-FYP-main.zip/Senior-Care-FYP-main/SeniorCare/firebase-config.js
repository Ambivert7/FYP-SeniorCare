export const firebaseConfig = {
    apiKey: "AIzaSyBVNpTgrSRtec8-wwCX3UmaF35WAd9X-Rk",
    authDomain: "health-fit-86927.firebaseapp.com",
    projectId: "health-fit-86927",
    storageBucket: "health-fit-86927.appspot.com",
    messagingSenderId: "306759770710",
    appId: "1:306759770710:web:63879ec2d5be88d9bc91f7",
    measurementId: "G-1WBYVEN659"
};